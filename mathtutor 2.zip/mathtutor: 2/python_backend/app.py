def solve_trigonometry(self, problem_text):
    steps = [f"Equation: {problem_text}"]
    # convert “sin(x)=a” → sin(x) - a = 0
    expr = parse_expr(problem_text.replace("=", "-(") + ")", transformations=self.transformations)
    var = list(expr.free_symbols)[0]
    sols = sp.solveset(expr, var, domain=sp.S.Reals)
    steps.append(f"Solve for {var}: {var} ∈ {sols}")
    return {"solution": str(sols), "steps": steps, "type": "trigonometry"}

def solve_calculus(self, problem_text):
    txt = problem_text.lower()
    var = sp.Symbol('x')
    if "derivative" in txt or "differentiate" in txt:
        func = parse_expr(re.search(r'derivative of (.+)', txt).group(1),
                          transformations=self.transformations)
        d = sp.diff(func, var)
        return {"solution": str(d),
                "steps":[f"d/dx {func} = {d}"],
                "type":"calculus"}
    if "integral" in txt or "integrate" in txt:
        func = parse_expr(re.search(r'integral of (.+)', txt).group(1),
                          transformations=self.transformations)
        F = sp.integrate(func, var)
        return {"solution": f"{F} + C",
                "steps":[f"∫ {func} dx = {F} + C"],
                "type":"calculus"}
    return {"error":"Unsupported calculus format."}

from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__, static_folder="../frontend", template_folder="../frontend")

# Serve index.html at /
@app.route("/")
def serve_login():
    return send_from_directory(app.static_folder, "index.html")

# Serve CSS/JS under /static/*
@app.route("/static/<path:filename>")
def serve_static(filename):
    return send_from_directory(app.static_folder, filename)

import sympy as sp
import numpy as np
import re
from sympy import Eq, solve
from sympy.parsing.sympy_parser import parse_expr, standard_transformations, implicit_multiplication_application
from flask import Flask, request, jsonify

class MathSolver:
    """Main class for solving various middle school math problems with step-by-step explanations"""
    def __init__(self):
        # Set up parsing transformations for sympy
        self.transformations = standard_transformations + (implicit_multiplication_application,)

    def solve_problem(self, problem_text, topic=None):
        """Entry point for all math problems - routes to appropriate solver"""
        problem_text = problem_text.strip()
        if not topic:
            topic = self._detect_problem_type(problem_text)

            elif topic == "statistics":
        return self.solve_statistics(problem_text)
+   elif topic == "trigonometry":
+       return self.solve_trigonometry(problem_text)
+   elif topic == "calculus":
+       return self.solve_calculus(problem_text)
    else:
        return self.solve_arithmetic(problem_text)

    def _detect_problem_type(self, problem_text):
        """Detects the type of math problem based on keywords and structure"""
        txt = problem_text.lower()
        # Fractions first
        if re.search(r'\d+\s*/\s*\d+', txt):
            return "fractions"
        if "%" in txt or "percent" in txt:
            return "percentages"
            +    # ─────────── support trig ───────────
+    if any(k in txt for k in ["sin(", "cos(", "tan(", "csc(", "sec(", "cot("]):
+        return "trigonometry"
+    # ─────────── support calculus ───────────
+    if any(k in txt for k in ["derivative", "differentiate", "integral", "integrate", "limit"]):
+        return "calculus"
        if any(k in txt for k in ["area", "perimeter", "volume", "circle", "triangle", "rectangle", "square", "angle"]):
            return "geometry"
        if any(k in txt for k in ["mean", "median", "mode", "average", "data", "probability"]):
            return "statistics"
        if any(k in txt for k in ["solve", "equation", "variable", "unknown"]) or (
            "=" in txt and not re.search(r'\d+\s*/\s*\d+', txt)
        ):
            return "algebra"
        return "arithmetic"

    def solve_algebra(self, problem_text):
        steps = []
        # Only split on colon if clearly prefixed with 'solve for'
        match = re.match(r'solve\s+for\s+([a-zA-Z])\s*:\s*(.+)', problem_text, re.IGNORECASE)
        if match:
            var_name = match.group(1)
            expr_text = match.group(2)
        else:
            var_name = None
            expr_text = problem_text

        # Strict equation extraction
        eq_match = re.search(r'([A-Za-z0-9+\-*/^\s()]+=[A-Za-z0-9+\-*/^\s()]+)', expr_text)
        if not eq_match:
            return {"error": "Couldn't identify an equation in the problem."}

        equation_text = eq_match.group(1)
        left_text, right_text = equation_text.split('=', 1)
        left_expr = parse_expr(left_text.replace('^', '**'), transformations=self.transformations)
        right_expr = parse_expr(right_text.replace('^', '**'), transformations=self.transformations)
        equation = Eq(left_expr, right_expr)

        # Detect variable
        if var_name:
            variable = sp.Symbol(var_name)
        else:
            syms = equation.free_symbols
            if len(syms) == 1:
                variable = syms.pop()
            elif sp.Symbol('x') in syms:
                variable = sp.Symbol('x')
            elif syms:
                variable = next(iter(syms))
            else:
                return {"error": "No variable found in the equation."}

        steps.append(f"Equation: {equation}")
        # Solve directly
        solutions = solve(equation, variable)
        if not solutions:
            return {"error": "No solution found."}
        solution = solutions[0]
        steps.append(f"Solve for {variable}: {variable} = {solution}")

        # Verification
        lhs_val = equation.lhs.subs(variable, solution)
        rhs_val = equation.rhs.subs(variable, solution)
        steps.append(f"Verification: {lhs_val} = {rhs_val}")

        return {"solution": str(solution), "steps": steps, "type": "algebra"}

    def solve_arithmetic(self, problem_text):
        steps = []
        m = re.search(r'(calculate|what is|find|evaluate|compute)\s+(.+?)(\?|\.|\n|$)', problem_text, re.IGNORECASE)
        if m:
            expression_text = m.group(2).strip()
        else:
            m2 = re.search(r'(\d+\s*[-+*/^]\s*\d+)', problem_text)
            if m2:
                expression_text = m2.group(1)
            else:
                return {"error": "Couldn't identify an arithmetic expression in the problem."}

        # Normalize operators
        ops_map = {
            'divided by': '/', 'multiplied by': '*', 'times': '*',
            'plus': '+', 'minus': '-', '^': '**'
        }
        for k, v in ops_map.items():
            expression_text = re.sub(k, v, expression_text)

        expr = parse_expr(expression_text, transformations=self.transformations)
        steps.append(f"Original expression: {expr}")
        result = expr.evalf()
        steps.append(f"Final result: {expr} = {result}")

        return {"solution": str(result), "steps": steps, "type": "arithmetic"}

    def solve_fractions(self, problem_text):
        steps = []
        m = re.search(r'(\d+\s*/\s*\d+)\s*(\+|\-|\*|/|divided by|times|multiplied by)\s*(\d+\s*/\s*\d+)', problem_text)
        if not m:
            return {"error": "Couldn't identify a fraction operation in the problem."}
        full = m.group(0)
        # Normalize text operators
        full = re.sub(r'divided by', '/', full)
        full = re.sub(r'multiplied by', '*', full)
        full = re.sub(r'times', '*', full)

        expr = parse_expr(full, transformations=self.transformations)
        f1 = parse_expr(m.group(1), transformations=self.transformations)
        f2 = parse_expr(m.group(3), transformations=self.transformations)
        op = m.group(2)

        if op in ['+', '-']:
            result = f1 + f2 if op == '+' else f1 - f2
        elif op in ['*', '×']:
            result = f1 * f2
        else:
            result = f1 / f2

        steps.append(f"Original problem: {f1} {op} {f2}")
        steps.append(f"Result: {result}")

        return {"solution": str(result), "steps": steps, "type": "fractions"}

    def solve_percentages(self, problem_text):
        steps = []
        txt = problem_text.lower()
        patterns = [
            (r'what\s+is\s+(\d+\.?\d*)%\s+of\s+(\d+\.?\d*)', 'part_of'),
            (r'(\d+\.?\d*)\s+is\s+what\s+percent\s+of\s+(\d+\.?\d*)', 'what_percent'),
            (r'(\d+\.?\d*)\s+is\s+(\d+\.?\d*)%\s+of\s+what', 'of_what')
        ]
        for pat, kind in patterns:
            m = re.search(pat, txt)
            if m:
                a, b = float(m.group(1)), float(m.group(2))
                if kind == 'part_of':
                    steps.append(f"Find {a}% of {b}:")
                    result = (a / 100) * b
                elif kind == 'what_percent':
                    steps.append(f"Find what percent {a} is of {b}:")
                    result = (a / b) * 100
                else:
                    steps.append(f"Find base when {a} is {b}% of it:")
                    result = a / (b / 100)
                steps.append(f"Result = {result}")
                return {"solution": str(result), "steps": steps, "type": "percentages"}
        return {"error": "Couldn't identify a percentage problem pattern."}

    def solve_geometry(self, problem_text):
        steps = []
        txt = problem_text.lower()
        # Area of rectangle
        m = re.search(r'length\s+(\d+\.?\d*)\s*(?:cm|)?\s+width\s+(\d+\.?\d*)', txt)
        if 'area' in txt and m:
            L, W = float(m.group(1)), float(m.group(2))
            steps.append(f"Area = length × width = {L} × {W} = {L * W}")
            return {"solution": str(L * W), "steps": steps, "type": "geometry"}
        # Circumference of circle
        m = re.search(r'radius\s+(\d+\.?\d*)', txt)
        if 'circle' in txt and m:
            r = float(m.group(1))
            steps.append(f"Circumference = 2πr = 2×π×{r} = {2 * sp.pi * r}")
            return {"solution": str(2 * sp.pi * r), "steps": steps, "type": "geometry"}
        # Area of triangle
        m = re.search(r'base\s+(\d+\.?\d*)\s+height\s+(\d+\.?\d*)', txt)
        if 'triangle' in txt and m:
            b, h = float(m.group(1)), float(m.group(2))
            steps.append(f"Area = ½×base×height = 0.5×{b}×{h} = {(b * h) / 2}")
            return {"solution": str((b * h) / 2), "steps": steps, "type": "geometry"}
        return {"error": "Couldn't identify a geometry problem pattern."}

    def solve_statistics(self, problem_text):
        steps = []
        nums = re.findall(r'\d+\.?\d*', problem_text)
        vals = list(map(float, nums)) if nums else []
        txt = problem_text.lower()
        if ('mean' in txt or 'average' in txt) and vals:
            mean_val = sum(vals) / len(vals)
            steps.append(f"Mean = sum(vals)/n = {sum(vals)}/{len(vals)} = {mean_val}")
            return {"solution": str(mean_val), "steps": steps, "type": "statistics"}
        if 'median' in txt and vals:
            s = sorted(vals)
            n = len(s)
            if n % 2:
                median_val = s[n // 2]
            else:
                median_val = (s[n // 2 - 1] + s[n // 2]) / 2
            steps.append(f"Sorted = {s}, Median = {median_val}")
            return {"solution": str(median_val), "steps": steps, "type": "statistics"}
        if 'mode' in txt and vals:
            freq = {v: vals.count(v) for v in set(vals)}
            maxf = max(freq.values())
            modes = [v for v, f in freq.items() if f == maxf]
            steps.append(f"Frequencies = {freq}, Mode(s) = {modes}")
            return {"solution": str(modes), "steps": steps, "type": "statistics"}
        return {"error": "Couldn't identify a statistics problem pattern."}

# Flask API wrapper
app = Flask(__name__)
solver = MathSolver()

@app.route('/solve', methods=['POST'])
def solve_endpoint():
    data = request.json
    if not data or 'problem' not in data:
        return jsonify({'error': 'No problem provided'}), 400
    result = solver.solve_problem(data['problem'], data.get('topic'))
    return jsonify(result)

@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'ok'})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5001)

