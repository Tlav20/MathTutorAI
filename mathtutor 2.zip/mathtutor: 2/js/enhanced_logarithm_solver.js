/**
 * Enhanced logarithmic equation solver
 * Handles various forms of logarithmic equations with detailed steps
 * @param {string} equation - The logarithmic equation
 * @returns {Object} - Solution with detailed steps and visualizations
 */
function solveLogarithmicEquation(equation) {
    // Normalize the equation
    equation = equation.trim();
    
    const steps = [];
    
    // Step 1: Starting with the original equation
    steps.push({
        equation: equation,
        explanation: 'Start with the original logarithmic equation.',
        result: null
    });
    
    // Check if the equation contains equals sign
    if (!equation.includes('=')) {
        throw new Error('Equation must include an equals sign');
    }
    
    // Check various forms of logarithmic equations
    
    // 1. Basic form: log_b(x) = k
    const basicLogRegex = /log(?:_(\d+))?\(([a-zA-Z])\)\s*=\s*(.+)/;
    
    // 2. Natural log form: ln(x) = k
    const lnRegex = /ln\(([a-zA-Z])\)\s*=\s*(.+)/;
    
    // 3. Log of expression: log_b(expression) = k
    const logExpressionRegex = /log(?:_(\d+))?\((.+)\)\s*=\s*(.+)/;
    
    // 4. Multiple logs: log_b(x) + log_b(y) = k or log_b(x) - log_b(y) = k
    const multipleLogsRegex = /log(?:_(\d+))?\(([^)]+)\)\s*([+-])\s*log(?:_\1)?\(([^)]+)\)\s*=\s*(.+)/;
    
    // 5. Log equality: log_b(x) = log_b(y)
    const logEqualityRegex = /log(?:_(\d+))?\(([^)]+)\)\s*=\s*log(?:_\1)?\(([^)]+)\)/;
    
    let variable, base, value, solution, expression;
    
    // Case 1: Basic form log_b(x) = k
    if (equation.match(basicLogRegex)) {
        const match = equation.match(basicLogRegex);
        base = match[1] ? parseInt(match[1]) : 10; // Default base is 10
        variable = match[2];
        value = parseFloat(match[3]);
        
        steps.push({
            equation: `log_${base}(${variable}) = ${value}`,
            explanation: `Identify the base (${base}), variable (${variable}), and value (${value}).`,
            result: null
        });
        
        steps.push({
            equation: `${variable} = ${base}^{${value}}`,
            explanation: `Convert logarithmic equation to exponential form. log_${base}(${variable}) = ${value} means ${variable} = ${base}^{${value}}.`,
            result: null
        });
        
        solution = Math.pow(base, value);
        
        steps.push({
            equation: `${variable} = ${solution}`,
            explanation: `Calculate ${base}^{${value}} = ${solution}.`,
            result: `${variable} = ${solution}`
        });
        
        return {
            type: 'logarithmic',
            variable: variable,
            solution: solution,
            steps: steps,
            visualizationType: 'basic-logarithm'
        };
    }
    
    // Case 2: Natural log form ln(x) = k
    else if (equation.match(lnRegex)) {
        const match = equation.match(lnRegex);
        variable = match[1];
        value = parseFloat(match[2]);
        base = Math.E; // Natural logarithm has base e
        
        steps.push({
            equation: `ln(${variable}) = ${value}`,
            explanation: `Identify the natural logarithm of variable (${variable}) equal to ${value}.`,
            result: null
        });
        
        steps.push({
            equation: `${variable} = e^{${value}}`,
            explanation: `Convert natural logarithm equation to exponential form. ln(${variable}) = ${value} means ${variable} = e^{${value}}.`,
            result: null
        });
        
        solution = Math.exp(value);
        
        steps.push({
            equation: `${variable} = ${solution.toFixed(6)}`,
            explanation: `Calculate e^{${value}} ≈ ${solution.toFixed(6)}.`,
            result: `${variable} = ${solution.toFixed(6)}`
        });
        
        return {
            type: 'logarithmic',
            variable: variable,
            solution: solution,
            steps: steps,
            visualizationType: 'natural-logarithm'
        };
    }
    
    // Case 3: Log of expression: log_b(expression) = k
    else if (equation.match(logExpressionRegex) && !equation.match(basicLogRegex)) {
        const match = equation.match(logExpressionRegex);
        base = match[1] ? parseInt(match[1]) : 10; // Default base is 10
        expression = match[2];
        value = parseFloat(match[3]);
        
        // Try to identify variable in expression
        const variableMatch = expression.match(/[a-zA-Z]/);
        variable = variableMatch ? variableMatch[0] : 'x';
        
        steps.push({
            equation: `log_${base}(${expression}) = ${value}`,
            explanation: `Identify the logarithm of expression (${expression}) with base ${base} equal to ${value}.`,
            result: null
        });
        
        steps.push({
            equation: `${expression} = ${base}^{${value}}`,
            explanation: `Convert logarithmic equation to exponential form. log_${base}(${expression}) = ${value} means ${expression} = ${base}^{${value}}.`,
            result: null
        });
        
        const rightSide = Math.pow(base, value);
        
        steps.push({
            equation: `${expression} = ${rightSide}`,
            explanation: `Calculate ${base}^{${value}} = ${rightSide}.`,
            result: null
        });
        
        // Special case: expression is of the form "variable + constant" or "variable - constant"
        const linearExpressionRegex = new RegExp(`${variable}\\s*([+-])\\s*(\\d+)`);
        if (expression.match(linearExpressionRegex)) {
            const expressionMatch = expression.match(linearExpressionRegex);
            const operator = expressionMatch[1];
            const constant = parseFloat(expressionMatch[2]);
            
            if (operator === '+') {
                solution = rightSide - constant;
                steps.push({
                    equation: `${variable} + ${constant} = ${rightSide}`,
                    explanation: `Isolate the variable by subtracting ${constant} from both sides.`,
                    result: null
                });
                
                steps.push({
                    equation: `${variable} = ${rightSide} - ${constant} = ${solution}`,
                    explanation: `Solve for ${variable}.`,
                    result: `${variable} = ${solution}`
                });
            } else { // operator is '-'
                solution = rightSide + constant;
                steps.push({
                    equation: `${variable} - ${constant} = ${rightSide}`,
                    explanation: `Isolate the variable by adding ${constant} to both sides.`,
                    result: null
                });
                
                steps.push({
                    equation: `${variable} = ${rightSide} + ${constant} = ${solution}`,
                    explanation: `Solve for ${variable}.`,
                    result: `${variable} = ${solution}`
                });
            }
            
            return {
                type: 'logarithmic',
                variable: variable,
                solution: solution,
                steps: steps,
                visualizationType: 'log-expression'
            };
        }
        
        // For more complex expressions, we indicate that further algebraic manipulation is needed
        steps.push({
            equation: `Solve for ${variable} in the equation ${expression} = ${rightSide}`,
            explanation: `This requires solving an algebraic equation to isolate ${variable}.`,
            result: `${expression} = ${rightSide}`
        });
        
        return {
            type: 'logarithmic',
            variable: variable,
            partialSolution: `${expression} = ${rightSide}`,
            steps: steps,
            visualizationType: 'log-expression'
        };
    }
    
    // Case 4: Multiple logs: log_b(x) + log_b(y) = k or log_b(x) - log_b(y) = k
    else if (equation.match(multipleLogsRegex)) {
        const match = equation.match(multipleLogsRegex);
        base = match[1] ? parseInt(match[1]) : 10; // Default base is 10
        const expr1 = match[2];
        const operator = match[3]; // '+' or '-'
        const expr2 = match[4];
        value = parseFloat(match[5]);
        
        // Try to identify variable in expressions
        const variableMatch = (expr1 + expr2).match(/[a-zA-Z]/);
        variable = variableMatch ? variableMatch[0] : 'x';
        
        steps.push({
            equation: `log_${base}(${expr1}) ${operator} log_${base}(${expr2}) = ${value}`,
            explanation: `Identify the equation with multiple logarithms.`,
            result: null
        });
        
        // Apply logarithm properties
        if (operator === '+') {
            steps.push({
                equation: `log_${base}(${expr1} × ${expr2}) = ${value}`,
                explanation: `Apply the logarithm property: log_b(x) + log_b(y) = log_b(x×y).`,
                result: null
            });
            
            steps.push({
                equation: `${expr1} × ${expr2} = ${base}^{${value}}`,
                explanation: `Convert to exponential form.`,
                result: null
            });
            
            const rightSide = Math.pow(base, value);
            
            steps.push({
                equation: `${expr1} × ${expr2} = ${rightSide}`,
                explanation: `Calculate ${base}^{${value}} = ${rightSide}.`,
                result: `${expr1} × ${expr2} = ${rightSide}`
            });
            
            return {
                type: 'logarithmic',
                variable: variable,
                partialSolution: `${expr1} × ${expr2} = ${rightSide}`,
                steps: steps,
                visualizationType: 'log-product'
            };
        } else { // operator is '-'
            steps.push({
                equation: `log_${base}(${expr1} ÷ ${expr2}) = ${value}`,
                explanation: `Apply the logarithm property: log_b(x) - log_b(y) = log_b(x÷y).`,
                result: null
            });
            
            steps.push({
                equation: `${expr1} ÷ ${expr2} = ${base}^{${value}}`,
                explanation: `Convert to exponential form.`,
                result: null
            });
            
            const rightSide = Math.pow(base, value);
            
            steps.push({
                equation: `${expr1} ÷ ${expr2} = ${rightSide}`,
                explanation: `Calculate ${base}^{${value}} = ${rightSide}.`,
                result: null
            });
            
            steps.push({
                equation: `${expr1} = ${rightSide} × ${expr2}`,
                explanation: `Multiply both sides by ${expr2}.`,
                result: `${expr1} = ${rightSide} × ${expr2}`
            });
            
            return {
                type: 'logarithmic',
                variable: variable,
                partialSolution: `${expr1} = ${rightSide} × ${expr2}`,
                steps: steps,
                visualizationType: 'log-quotient'
            };
        }
    }
    
    // Case 5: Log equality: log_b(x) = log_b(y)
    else if (equation.match(logEqualityRegex)) {
        const match = equation.match(logEqualityRegex);
        base = match[1] ? parseInt(match[1]) : 10; // Default base is 10
        const expr1 = match[2];
        const expr2 = match[3];
        
        // Try to identify variable in expressions
        const variableMatch = (expr1 + expr2).match(/[a-zA-Z]/);
        variable = variableMatch ? variableMatch[0] : 'x';
        
        steps.push({
            equation: `log_${base}(${expr1}) = log_${base}(${expr2})`,
            explanation: `Identify the logarithmic equality.`,
            result: null
        });
        
        steps.push({
            equation: `${expr1} = ${expr2}`,
            explanation: `Apply the property: If log_b(x) = log_b(y), then x = y (assuming b > 0, b ≠ 1).`,
            result: `${expr1} = ${expr2}`
        });
        
        return {
            type: 'logarithmic',
            variable: variable,
            partialSolution: `${expr1} = ${expr2}`,
            steps: steps,
            visualizationType: 'log-equality'
        };
    }
    
    else {
        throw new Error('Unsupported logarithmic equation format');
    }
}