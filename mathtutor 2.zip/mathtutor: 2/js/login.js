document.addEventListener('DOMContentLoaded', () => {
    // Tab buttons and form containers
    const loginTab      = document.getElementById('login-tab');
    const registerTab   = document.getElementById('register-tab');
    const loginFormDiv  = document.getElementById('login-form');
    const registerFormDiv = document.getElementById('register-form');
    const backToLoginBtn = document.getElementById('back-to-login');
  
    function showLogin() {
      loginTab.classList.add('active');
      registerTab.classList.remove('active');
      loginFormDiv.classList.add('active');
      registerFormDiv.classList.remove('active');
    }
  
    function showRegister() {
      registerTab.classList.add('active');
      loginTab.classList.remove('active');
      registerFormDiv.classList.add('active');
      loginFormDiv.classList.remove('active');
    }
  
    // Event listeners for tab switching
    loginTab.addEventListener('click', showLogin);
    registerTab.addEventListener('click', showRegister);
    document.getElementById('go-to-register').addEventListener('click', e => {
      e.preventDefault();
      showRegister();
    });
    document.getElementById('go-to-login').addEventListener('click', e => {
      e.preventDefault();
      showLogin();
    });

    // Back button functionality
    if (backToLoginBtn) {
      backToLoginBtn.addEventListener('click', showLogin);
    }
  
    // Password strength meter on register form
    const pwdInput = document.getElementById('register-password');
    const strengthBar  = document.getElementById('strength-bar');
    const strengthText = document.getElementById('strength-text');
  
    pwdInput.addEventListener('input', () => {
      const val = pwdInput.value;
      let score = 0;
      if (val.length >= 8) score++;
      if (/[A-Z]/.test(val)) score++;
      if (/[0-9]/.test(val)) score++;
      if (/[\W_]/.test(val)) score++;
      // score 0..4
      strengthBar.style.width = (score / 4 * 100) + '%';
      const labels = ['Very Weak','Weak','Fair','Good','Strong'];
      strengthText.textContent = labels[score];
      
      // Set the color based on score
      let color;
      switch(score) {
        case 0: color = '#e74c3c'; break; // Red
        case 1: color = '#e67e22'; break; // Orange
        case 2: color = '#f1c40f'; break; // Yellow
        case 3: color = '#2ecc71'; break; // Light Green
        case 4: color = '#27ae60'; break; // Dark Green
      }
      strengthBar.style.backgroundColor = color;
    });
  
    // Notification modal (for "Forgot Password")
    const modal        = document.getElementById('notification-modal');
    const closeModal   = modal.querySelector('.close-modal');
    const confirmModal = document.getElementById('confirm-modal');
    const recipient    = document.getElementById('recipient-email');
    const bodyElem     = document.getElementById('email-body');
    
    document.getElementById('forgot-password').addEventListener('click', e => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      if (!email) {
        alert('Please enter your email first.');
        return;
      }
      recipient.textContent = email;
      bodyElem.innerHTML = `
        <p>Hi there,</p>
        <p>You asked to reset your MathTutor password. Click the link below to choose a new one:</p>
        <p><a href="#">Reset your password</a></p>
        <p>If you didn't request this, just ignore this email.</p>
        <p>Thanks,<br>MathTutor Team</p>
      `;
      modal.style.display = 'flex';
    });
    
    closeModal.addEventListener('click', () => modal.style.display = 'none');
    confirmModal.addEventListener('click', () => modal.style.display = 'none');
  
    // Registration form
    const regForm = document.getElementById('register-form-element');
    regForm.addEventListener('submit', e => {
      e.preventDefault();
      // grab fields
      const name    = document.getElementById('register-name').value.trim();
      const email   = document.getElementById('register-email').value.trim();
      const pwd     = document.getElementById('register-password').value;
      const confirm = document.getElementById('register-confirm').value;
      const terms   = document.getElementById('terms').checked;
      
      // clear previous errors
      ['name','email','password','confirm'].forEach(id => {
        document.getElementById(`register-${id}-error`).textContent = '';
      });
      
      let valid = true;
      if (!name) {
        document.getElementById('register-name-error').textContent = 'Name is required.';
        valid = false;
      }
      if (!email) {
        document.getElementById('register-email-error').textContent = 'Email is required.';
        valid = false;
      }
      if (pwd.length < 6) {
        document.getElementById('register-password-error').textContent = 'At least 6 characters.';
        valid = false;
      }
      if (pwd !== confirm) {
        document.getElementById('register-confirm-error').textContent = 'Passwords must match.';
        valid = false;
      }
      if (!terms) {
        alert('You must agree to the Terms & Conditions.');
        valid = false;
      }
  
      if (!valid) return;
  
      // Save to localStorage (demo purposes)
      localStorage.setItem('mathTutorUserName', name);
      localStorage.setItem('mathTutorUserEmail', email);
      localStorage.setItem('mathTutorUserPassword', pwd);
      
      // Get first name only if there are multiple words
      const firstName = name.split(' ')[0];
      localStorage.setItem('mathTutorUserInitial', firstName.charAt(0).toUpperCase());
      
      // Direct to main page - check if index.html exists
      try {
        window.location.href = 'index.html';
      } catch (error) {
        // Fallback if index.html does not exist
        alert('Registration successful! The main page would load here in a complete application.');
        showLogin();
      }
    });
  
    // Login form
    const loginForm = document.getElementById('login-form-element');
    loginForm.addEventListener('submit', e => {
      e.preventDefault();
      const email = document.getElementById('login-email').value.trim();
      const pwd   = document.getElementById('login-password').value;
      
      // clear errors
      document.getElementById('login-email-error').textContent = '';
      document.getElementById('login-password-error').textContent = '';
      
      let ok = true;
      if (!email) {
        document.getElementById('login-email-error').textContent = 'Email is required.';
        ok = false;
      }
      if (!pwd) {
        document.getElementById('login-password-error').textContent = 'Password is required.';
        ok = false;
      }
      if (!ok) return;
  
      // Check against saved credentials
      const savedEmail = localStorage.getItem('mathTutorUserEmail');
      const savedPwd   = localStorage.getItem('mathTutorUserPassword');
      
      if (!savedEmail || !savedPwd) {
        document.getElementById('login-password-error').textContent = 'Please register first.';
        return;
      }
      
      if (email !== savedEmail || pwd !== savedPwd) {
        document.getElementById('login-password-error').textContent = 'Invalid email or password.';
        return;
      }
  
      // Success! - Direct to main page
      try {
        window.location.href = 'index.html';
      } catch (error) {
        // Fallback if index.html does not exist
        alert('Login successful! The main page would load here in a complete application.');
      }
    });
    
    // Check for direct registration/login links in URL
    if (window.location.hash === '#register') {
      showRegister();
    }
});