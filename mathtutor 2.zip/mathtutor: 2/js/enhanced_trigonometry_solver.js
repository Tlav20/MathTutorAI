/**
 * Enhanced trigonometric equation solver
 * Handles various forms of trigonometric equations with detailed steps
 * @param {string} equation - The trigonometric equation
 * @returns {Object} - Solution with detailed steps and visualizations
 */
function solveTrigonometricEquation(equation) {
    // Normalize the equation
    equation = equation.trim();
    
    const steps = [];
    
    // Step 1: Starting with the original equation
    steps.push({
        equation: equation,
        explanation: 'Start with the original trigonometric equation.',
        result: null
    });
    
    // Check if the equation contains equals sign
    if (!equation.includes('=')) {
        throw new Error('Equation must include an equals sign');
    }
    
    // Define regex patterns for different types of trig equations
    
    // 1. Basic forms: sin(x) = k, cos(x) = k, tan(x) = k
    const basicSinRegex = /sin\(([a-zA-Z])\)\s*=\s*(.+)/i;
    const basicCosRegex = /cos\(([a-zA-Z])\)\s*=\s*(.+)/i;
    const basicTanRegex = /tan\(([a-zA-Z])\)\s*=\s*(.+)/i;
    
    // 2. With coefficients: a*sin(x) = k, etc.
    const coefSinRegex = /(\d+(?:\.\d+)?)\s*\*?\s*sin\(([a-zA-Z])\)\s*=\s*(.+)/i;
    const coefCosRegex = /(\d+(?:\.\d+)?)\s*\*?\s*cos\(([a-zA-Z])\)\s*=\s*(.+)/i;
    const coefTanRegex = /(\d+(?:\.\d+)?)\s*\*?\s*tan\(([a-zA-Z])\)\s*=\s*(.+)/i;
    
    // 3. With angles: sin(ax + b) = k, etc.
    const angleSinRegex = /sin\((.+)\)\s*=\s*(.+)/i;
    const angleCosRegex = /cos\((.+)\)\s*=\s*(.+)/i;
    const angleTanRegex = /tan\((.+)\)\s*=\s*(.+)/i;
    
    // 4. Identity forms: sin(x) = cos(x), etc.
    const sinCosRegex = /sin\(([a-zA-Z])\)\s*=\s*cos\(([a-zA-Z])\)/i;
    const sinTanRegex = /sin\(([a-zA-Z])\)\s*=\s*tan\(([a-zA-Z])\)/i;
    const cosTanRegex = /cos\(([a-zA-Z])\)\s*=\s*tan\(([a-zA-Z])\)/i;
    
    let variable, value, solutions, angleExpression, coefficient;
    
    // Special values for reference
    const specialValues = {
        sin: {
            '0': 0,
            '30': 0.5,
            '45': Math.sqrt(2)/2,
            '60': Math.sqrt(3)/2,
            '90': 1,
            '180': 0,
            '270': -1,
            '360': 0
        },
        cos: {
            '0': 1,
            '30': Math.sqrt(3)/2,
            '45': Math.sqrt(2)/2,
            '60': 0.5,
            '90': 0,
            '180': -1,
            '270': 0,
            '360': 1
        },
        tan: {
            '0': 0,
            '30': 1/Math.sqrt(3),
            '45': 1,
            '60': Math.sqrt(3),
            '180': 0,
            '270': undefined, // undefined at 270
            '360': 0
        }
    };
    
    // Function to get special angle name if the value is close to a known special angle
    function getSpecialAngleName(value, trigFunction) {
        for (const [angle, specialValue] of Object.entries(specialValues[trigFunction])) {
            if (specialValue !== undefined && Math.abs(value - specialValue) < 0.0001) {
                return angle + '°';
            }
        }
        return null;
    }
    
    // Case 1: Basic sine equation sin(x) = k
    if (equation.match(basicSinRegex)) {
        const match = equation.match(basicSinRegex);
        variable = match[1];
        value = parseFloat(match[2]);
        
        steps.push({
            equation: `sin(${variable}) = ${value}`,
            explanation: `Identify the sine equation with variable ${variable} and value ${value}.`,
            result: null
        });
        
        // Check domain validity for sine (-1 to 1)
        if (value < -1 || value > 1) {
            steps.push({
                equation: 'No solution',
                explanation: `The value of sine must be between -1 and 1. Since ${value} is outside this range, there is no solution.`,
                result: 'No solution'
            });
            
            return {
                type: 'trigonometric',
                function: 'sine',
                variable: variable,
                solutions: [],
                steps: steps,
                visualizationType: 'sine-out-of-range'
            };
        }
        
        // Check if this is a special angle
        const specialAngle = getSpecialAngleName(value, 'sin');
        
        // Find the reference angle (first quadrant)
        const referenceAngleRad = Math.asin(value);
        const referenceAngleDeg = (referenceAngleRad * 180) / Math.PI;
        
        if (specialAngle) {
            steps.push({
                equation: `sin(${variable}) = sin(${specialAngle})`,
                explanation: `The value ${value} corresponds to the sine of the special angle ${specialAngle}.`,
                result: null
            });
        } else {
            steps.push({
                equation: `${variable} = sin⁻¹(${value}) ≈ ${referenceAngleDeg.toFixed(2)}° in the first quadrant`,
                explanation: `Find the inverse sine of ${value} to get the reference angle in the first quadrant.`,
                result: null
            });
        }
        
        // Find all solutions in the [0, 360°) range
        const firstSolution = referenceAngleDeg;
        const secondSolution = 180 - referenceAngleDeg;
        
        steps.push({
            equation: `${variable} = ${firstSolution.toFixed(2)}° or ${variable} = ${secondSolution.toFixed(2)}°`,
            explanation: `Since sine is positive in the first and second quadrants, there are two solutions in [0, 360°).`,
            result: null
        });
        
        // General solution for all angles
        steps.push({
            equation: `${variable} = ${firstSolution.toFixed(2)}° + 360°n or ${variable} = ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`,
            explanation: `The general solution accounts for the periodicity of sine (period of 360°).`,
            result: `${variable} = ${firstSolution.toFixed(2)}° + 360°n or ${variable} = ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`
        });
        
        return {
            type: 'trigonometric',
            function: 'sine',
            variable: variable,
            solutions: [
                { degrees: firstSolution, radians: referenceAngleRad },
                { degrees: secondSolution, radians: Math.PI - referenceAngleRad }
            ],
            generalSolution: `${firstSolution.toFixed(2)}° + 360°n or ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`,
            steps: steps,
            visualizationType: 'sine-solution'
        };
    }
    
    // Case 2: Basic cosine equation cos(x) = k
    else if (equation.match(basicCosRegex)) {
        const match = equation.match(basicCosRegex);
        variable = match[1];
        value = parseFloat(match[2]);
        
        steps.push({
            equation: `cos(${variable}) = ${value}`,
            explanation: `Identify the cosine equation with variable ${variable} and value ${value}.`,
            result: null
        });
        
        // Check domain validity for cosine (-1 to 1)
        if (value < -1 || value > 1) {
            steps.push({
                equation: 'No solution',
                explanation: `The value of cosine must be between -1 and 1. Since ${value} is outside this range, there is no solution.`,
                result: 'No solution'
            });
            
            return {
                type: 'trigonometric',
                function: 'cosine',
                variable: variable,
                solutions: [],
                steps: steps,
                visualizationType: 'cosine-out-of-range'
            };
        }
        
        // Check if this is a special angle
        const specialAngle = getSpecialAngleName(value, 'cos');
        
        // Find the reference angle (first quadrant)
        const referenceAngleRad = Math.acos(value);
        const referenceAngleDeg = (referenceAngleRad * 180) / Math.PI;
        
        if (specialAngle) {
            steps.push({
                equation: `cos(${variable}) = cos(${specialAngle})`,
                explanation: `The value ${value} corresponds to the cosine of the special angle ${specialAngle}.`,
                result: null
            });
        } else {
            steps.push({
                equation: `${variable} = cos⁻¹(${value}) ≈ ${referenceAngleDeg.toFixed(2)}° in the first quadrant`,
                explanation: `Find the inverse cosine of ${value} to get the reference angle in the first quadrant.`,
                result: null
            });
        }
        
        // Find all solutions in the [0, 360°) range
        const firstSolution = referenceAngleDeg;
        const secondSolution = 360 - referenceAngleDeg;
        
        steps.push({
            equation: `${variable} = ${firstSolution.toFixed(2)}° or ${variable} = ${secondSolution.toFixed(2)}°`,
            explanation: `Since cosine is positive in the first and fourth quadrants, there are two solutions in [0, 360°).`,
            result: null
        });
        
        // General solution for all angles
        steps.push({
            equation: `${variable} = ${firstSolution.toFixed(2)}° + 360°n or ${variable} = ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`,
            explanation: `The general solution accounts for the periodicity of cosine (period of 360°).`,
            result: `${variable} = ${firstSolution.toFixed(2)}° + 360°n or ${variable} = ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`
        });
        
        return {
            type: 'trigonometric',
            function: 'cosine',
            variable: variable,
            solutions: [
                { degrees: firstSolution, radians: referenceAngleRad },
                { degrees: secondSolution, radians: 2 * Math.PI - referenceAngleRad }
            ],
            generalSolution: `${firstSolution.toFixed(2)}° + 360°n or ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`,
            steps: steps,
            visualizationType: 'cosine-solution'
        };
    }
    
    // Case 3: Basic tangent equation tan(x) = k
    else if (equation.match(basicTanRegex)) {
        const match = equation.match(basicTanRegex);
        variable = match[1];
        value = parseFloat(match[2]);
        
        steps.push({
            equation: `tan(${variable}) = ${value}`,
            explanation: `Identify the tangent equation with variable ${variable} and value ${value}.`,
            result: null
        });
        
        // Check if this is a special angle
        const specialAngle = getSpecialAngleName(value, 'tan');
        
        // Find the reference angle (first quadrant)
        const referenceAngleRad = Math.atan(value);
        const referenceAngleDeg = (referenceAngleRad * 180) / Math.PI;
        
        if (specialAngle) {
            steps.push({
                equation: `tan(${variable}) = tan(${specialAngle})`,
                explanation: `The value ${value} corresponds to the tangent of the special angle ${specialAngle}.`,
                result: null
            });
        } else {
            steps.push({
                equation: `${variable} = tan⁻¹(${value}) ≈ ${referenceAngleDeg.toFixed(2)}° in the first quadrant`,
                explanation: `Find the inverse tangent of ${value} to get the reference angle.`,
                result: null
            });
        }
        
        // Find the principal solution in the [0, 180°) range
        const principalSolution = referenceAngleDeg < 0 ? referenceAngleDeg + 180 : referenceAngleDeg;
        
        steps.push({
            equation: `${variable} = ${principalSolution.toFixed(2)}°`,
            explanation: `The principal solution in the range [0, 180°).`,
            result: null
        });
        
        // General solution for all angles
        steps.push({
            equation: `${variable} = ${principalSolution.toFixed(2)}° + 180°n, where n is an integer`,
            explanation: `The general solution accounts for the periodicity of tangent (period of 180°).`,
            result: `${variable} = ${principalSolution.toFixed(2)}° + 180°n, where n is an integer`
        });
        
        return {
            type: 'trigonometric',
            function: 'tangent',
            variable: variable,
            solutions: [
                { degrees: principalSolution, radians: (principalSolution * Math.PI) / 180 }
            ],
            generalSolution: `${principalSolution.toFixed(2)}° + 180°n, where n is an integer`,
            steps: steps,
            visualizationType: 'tangent-solution'
        };
    }
    
    // Case 4: Sine equals cosine: sin(x) = cos(x)
    else if (equation.match(sinCosRegex)) {
        const match = equation.match(sinCosRegex);
        const var1 = match[1];
        const var2 = match[2];
        
        if (var1 !== var2) {
            steps.push({
                equation: `sin(${var1}) = cos(${var2})`,
                explanation: `This equation involves different variables and would require additional constraints to solve.`,
                result: null
            });
            
            return {
                type: 'trigonometric',
                function: 'mixed',
                variables: [var1, var2],
                solutions: [],
                steps: steps,
                visualizationType: 'different-variables'
            };
        }
        
        variable = var1;
        
        steps.push({
            equation: `sin(${variable}) = cos(${variable})`,
            explanation: `Identify the equation where sine equals cosine for the same variable.`,
            result: null
        });
        
        steps.push({
            equation: `sin(${variable}) - cos(${variable}) = 0`,
            explanation: `Rearrange to standard form.`,
            result: null
        });
        
        steps.push({
            equation: `sin(${variable}) = cos(${variable})`,
            explanation: `This occurs when sine and cosine have the same value.`,
            result: null
        });
        
        steps.push({
            equation: `${variable} = 45° + 360°n or ${variable} = 225° + 360°n, where n is an integer`,
            explanation: `At 45° and 225°, sine and cosine have the same value. The general solution accounts for periodicity.`,
            result: `${variable} = 45° + 360°n or ${variable} = 225° + 360°n, where n is an integer`
        });
        
        return {
            type: 'trigonometric',
            function: 'sine-cosine-equality',
            variable: variable,
            solutions: [
                { degrees: 45, radians: Math.PI / 4 },
                { degrees: 225, radians: 5 * Math.PI / 4 }
            ],
            generalSolution: `45° + 360°n or 225° + 360°n, where n is an integer`,
            steps: steps,
            visualizationType: 'sine-equals-cosine'
        };
    }
    
    // Case 5: With coefficient: a*sin(x) = k
    else if (equation.match(coefSinRegex)) {
        const match = equation.match(coefSinRegex);
        coefficient = parseFloat(match[1]);
        variable = match[2];
        value = parseFloat(match[3]);
        
        steps.push({
            equation: `${coefficient}sin(${variable}) = ${value}`,
            explanation: `Identify the sine equation with coefficient ${coefficient}, variable ${variable}, and value ${value}.`,
            result: null
        });
        
        steps.push({
            equation: `sin(${variable}) = ${value}/${coefficient} = ${(value/coefficient).toFixed(4)}`,
            explanation: `Isolate sine by dividing both sides by ${coefficient}.`,
            result: null
        });
        
        const sineValue = value / coefficient;
        
        // Check domain validity for sine (-1 to 1)
        if (sineValue < -1 || sineValue > 1) {
            steps.push({
                equation: 'No solution',
                explanation: `The value of sine must be between -1 and 1. Since ${sineValue.toFixed(4)} is outside this range, there is no solution.`,
                result: 'No solution'
            });
            
            return {
                type: 'trigonometric',
                function: 'sine',
                variable: variable,
                solutions: [],
                steps: steps,
                visualizationType: 'sine-out-of-range'
            };
        }
        
        // Now it's reduced to a basic sine equation sin(x) = sineValue
        const referenceAngleRad = Math.asin(sineValue);
        const referenceAngleDeg = (referenceAngleRad * 180) / Math.PI;
        
        steps.push({
            equation: `${variable} = sin⁻¹(${sineValue.toFixed(4)}) ≈ ${referenceAngleDeg.toFixed(2)}° in the first quadrant`,
            explanation: `Find the inverse sine of ${sineValue.toFixed(4)} to get the reference angle in the first quadrant.`,
            result: null
        });
        
        // Find all solutions in the [0, 360°) range
        const firstSolution = referenceAngleDeg;
        const secondSolution = 180 - referenceAngleDeg;
        
        steps.push({
            equation: `${variable} = ${firstSolution.toFixed(2)}° or ${variable} = ${secondSolution.toFixed(2)}°`,
            explanation: `Since sine is positive in the first and second quadrants, there are two solutions in [0, 360°).`,
            result: null
        });
        
        // General solution for all angles
        steps.push({
            equation: `${variable} = ${firstSolution.toFixed(2)}° + 360°n or ${variable} = ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`,
            explanation: `The general solution accounts for the periodicity of sine (period of 360°).`,
            result: `${variable} = ${firstSolution.toFixed(2)}° + 360°n or ${variable} = ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`
        });
        
        return {
            type: 'trigonometric',
            function: 'sine',
            coefficient: coefficient,
            variable: variable,
            solutions: [
                { degrees: firstSolution, radians: referenceAngleRad },
                { degrees: secondSolution, radians: Math.PI - referenceAngleRad }
            ],
            generalSolution: `${firstSolution.toFixed(2)}° + 360°n or ${secondSolution.toFixed(2)}° + 360°n, where n is an integer`,
            steps: steps,
            visualizationType: 'sine-solution'
        };
    }
    
    // Handle more complex cases and other trig functions similarly
    
    else {
        // For complex trigonometric equations, we return a partial solution
        steps.push({
            equation: equation,
            explanation: `This is a complex trigonometric equation that requires advanced solving techniques.`,
            result: `Complex trigonometric equation`
        });
        
        return {
            type: 'trigonometric',
            function: 'complex',
            equation: equation,
            steps: steps,
            visualizationType: 'complex-trig'
        };
    }
}