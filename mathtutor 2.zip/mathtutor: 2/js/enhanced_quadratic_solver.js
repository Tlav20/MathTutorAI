/**
 * Enhanced quadratic equation solver
 * Handles more complex cases with full parsing of various forms
 * @param {string} equation - The quadratic equation in any standard form
 * @returns {Object} - Solution with detailed steps and visualizations
 */
function solveQuadraticEquation(equation) {
    // Normalize the equation
    equation = equation.trim().replace(/\s+/g, '');
    
    const steps = [];
    
    // Step 1: Starting with the original equation
    steps.push({
        equation: equation,
        explanation: 'Start with the original quadratic equation.',
        result: null
    });
    
    // Check if the equation contains equals sign
    if (!equation.includes('=')) {
        throw new Error('Equation must include an equals sign');
    }
    
    // Split into left and right sides
    const sides = equation.split('=').map(side => side.trim());
    let leftSide = sides[0];
    let rightSide = sides[1];
    
    // Step 2: Move all terms to the left side (standard form)
    if (rightSide !== '0') {
        steps.push({
            equation: `${leftSide} - (${rightSide}) = 0`,
            explanation: 'Move all terms to the left side of the equation.',
            result: null
        });
        
        // Distribute and combine like terms
        const expressionToSolve = this.algebraicExpressionParser(`${leftSide}-(${rightSide})`);
        leftSide = expressionToSolve;
        rightSide = '0';
        
        steps.push({
            equation: `${leftSide} = 0`,
            explanation: 'Simplify the left side of the equation.',
            result: null
        });
    }
    
    // Step 3: Identify coefficients (ax² + bx + c = 0)
    const coefficients = extractQuadraticCoefficients(leftSide);
    const { a, b, c, variable } = coefficients;
    
    steps.push({
        equation: `${a !== 1 ? a : ''}${variable}² + ${b > 0 ? b : b}${variable} + ${c} = 0`,
        explanation: `Identify the coefficients in standard form: a=${a}, b=${b}, c=${c}`,
        result: null
    });
    
    // Handle special cases
    if (Math.abs(a) < 0.0000001) {  // a is approximately 0, so this is a linear equation
        steps.push({
            equation: `${b}${variable} + ${c} = 0`,
            explanation: 'The coefficient of x² is approximately 0, so this is actually a linear equation.',
            result: null
        });
        
        steps.push({
            equation: `${b}${variable} = ${-c}`,
            explanation: `Move the constant term to the right side.`,
            result: null
        });
        
        const solution = -c / b;
        
        steps.push({
            equation: `${variable} = ${solution}`,
            explanation: `Divide both sides by the coefficient of ${variable}.`,
            result: `${variable} = ${solution}`
        });
        
        return {
            type: 'linear',
            variable: variable,
            solution: solution,
            steps: steps
        };
    }
    
    // Step 4: Calculate the discriminant
    const discriminant = b * b - 4 * a * c;
    
    steps.push({
        equation: `Discriminant = b² - 4ac = ${b}² - 4(${a})(${c}) = ${discriminant}`,
        explanation: 'Calculate the discriminant to determine the number and type of solutions.',
        result: null
    });
    
    // Step 5: Apply the quadratic formula based on the discriminant
    if (discriminant > 0) {
        // Two real solutions
        const sqrtDiscriminant = Math.sqrt(discriminant);
        const solution1 = (-b + sqrtDiscriminant) / (2 * a);
        const solution2 = (-b - sqrtDiscriminant) / (2 * a);
        
        steps.push({
            equation: `${variable} = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}`,
            explanation: 'Use the quadratic formula to find the solutions.',
            result: null
        });
        
        steps.push({
            equation: `${variable} = \\frac{-(${b}) \\pm \\sqrt{${discriminant}}}{2(${a})}`,
            explanation: 'Substitute the values into the quadratic formula.',
            result: null
        });
        
        steps.push({
            equation: `${variable} = \\frac{${-b} \\pm ${Math.sqrt(discriminant).toFixed(4)}}{${2 * a}}`,
            explanation: 'Simplify the discriminant.',
            result: null
        });
        
        steps.push({
            equation: `${variable}_1 = \\frac{${-b} + ${Math.sqrt(discriminant).toFixed(4)}}{${2 * a}} = ${solution1.toFixed(4)}`,
            explanation: 'Calculate the first solution using the + sign.',
            result: null
        });
        
        steps.push({
            equation: `${variable}_2 = \\frac{${-b} - ${Math.sqrt(discriminant).toFixed(4)}}{${2 * a}} = ${solution2.toFixed(4)}`,
            explanation: 'Calculate the second solution using the - sign.',
            result: `${variable} = ${solution1.toFixed(4)} or ${variable} = ${solution2.toFixed(4)}`
        });
        
        return {
            type: 'quadratic',
            variable: variable,
            solutions: [solution1, solution2],
            discriminant: discriminant,
            coefficients: { a, b, c },
            steps: steps,
            visualizationType: 'two-real-roots'
        };
        
    } else if (discriminant === 0) {
        // One real solution (double root)
        const solution = -b / (2 * a);
        
        steps.push({
            equation: `${variable} = \\frac{-b}{2a}`,
            explanation: 'Since the discriminant is zero, there is one repeated solution (double root).',
            result: null
        });
        
        steps.push({
            equation: `${variable} = \\frac{-(${b})}{2(${a})} = ${solution}`,
            explanation: 'Substitute the values and calculate.',
            result: `${variable} = ${solution}`
        });
        
        return {
            type: 'quadratic',
            variable: variable,
            solutions: [solution],
            discriminant: discriminant,
            coefficients: { a, b, c },
            steps: steps,
            visualizationType: 'double-root'
        };
        
    } else {
        // Two complex solutions
        const realPart = -b / (2 * a);
        const imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
        
        steps.push({
            equation: `${variable} = \\frac{-b}{2a} \\pm \\frac{\\sqrt{-\\text{discriminant}}}{2a}i`,
            explanation: 'Since the discriminant is negative, there are two complex solutions.',
            result: null
        });
        
        steps.push({
            equation: `${variable} = \\frac{-(${b})}{2(${a})} \\pm \\frac{\\sqrt{${-discriminant}}}{2(${a})}i`,
            explanation: 'Substitute the values.',
            result: null
        });
        
        steps.push({
            equation: `${variable} = ${realPart.toFixed(4)} \\pm ${imaginaryPart.toFixed(4)}i`,
            explanation: 'Simplify to get the complex solutions.',
            result: `${variable} = ${realPart.toFixed(4)} + ${imaginaryPart.toFixed(4)}i or ${variable} = ${realPart.toFixed(4)} - ${imaginaryPart.toFixed(4)}i`
        });
        
        return {
            type: 'quadratic',
            variable: variable,
            solutions: [
                { real: realPart, imaginary: imaginaryPart },
                { real: realPart, imaginary: -imaginaryPart }
            ],
            discriminant: discriminant,
            coefficients: { a, b, c },
            steps: steps,
            visualizationType: 'complex-roots'
        };
    }
}

/**
 * Extract coefficients from a quadratic expression
 * @param {string} expression - The algebraic expression
 * @returns {Object} - Extracted coefficients a, b, c and the variable
 */
function extractQuadraticCoefficients(expression) {
    // First, identify the variable being used
    const variableMatch = expression.match(/[a-zA-Z]/);
    if (!variableMatch) {
        throw new Error('No variable found in the expression');
    }
    
    const variable = variableMatch[0];
    
    // Replace spaces and standardize the expression format
    let standardizedExpression = expression.replace(/\s+/g, '')
                                          .replace(/-/g, '+-')
                                          .replace(/\^\s*2/g, '²')
                                          .replace(new RegExp(`\\${variable}\\*\\${variable}`, 'g'), `${variable}²`);
    
    if (standardizedExpression.startsWith('+')) {
        standardizedExpression = standardizedExpression.substring(1);
    }
    
    // Split into terms
    const terms = standardizedExpression.split('+').filter(term => term !== '');
    
    // Initialize coefficients
    let a = 0, b = 0, c = 0;
    
    // Extract coefficients from each term
    for (let term of terms) {
        if (term.includes(`${variable}²`)) {
            // Coefficient of x²
            const coefMatch = term.match(new RegExp(`(-?\\d*\\.?\\d*)${variable}²`));
            if (coefMatch) {
                const coefStr = coefMatch[1];
                a += coefStr === '' ? 1 : coefStr === '-' ? -1 : parseFloat(coefStr);
            }
        } else if (term.includes(variable)) {
            // Coefficient of x
            const coefMatch = term.match(new RegExp(`(-?\\d*\\.?\\d*)${variable}`));
            if (coefMatch) {
                const coefStr = coefMatch[1];
                b += coefStr === '' ? 1 : coefStr === '-' ? -1 : parseFloat(coefStr);
            }
        } else {
            // Constant term
            c += parseFloat(term) || 0;
        }
    }
    
    return { a, b, c, variable };
}

/**
 * Parse and simplify an algebraic expression
 * This is a placeholder for a more advanced algebraic parser
 * @param {string} expression - The algebraic expression to parse
 * @returns {string} - The simplified expression
 */
function algebraicExpressionParser(expression) {
    // In a real implementation, this would be a comprehensive parser
    // For now, we'll just return the expression as-is
    return expression;
}