// MathTutor Main JavaScript

document.addEventListener('DOMContentLoaded', () => {
    // Initialize user data
    const initializeUser = () => {
        const userInitial = document.getElementById('user-initial');
        if (!userInitial) return;
        
        // Get user data from localStorage
        const userName = localStorage.getItem('mathTutorUserName');
        const userEmail = localStorage.getItem('mathTutorUserEmail');
        const initial = localStorage.getItem('mathTutorUserInitial');
        
        // If no user data, redirect to login
        if (!userName || !userEmail) {
            window.location.href = 'login.html';
            return;
        }
        
        // Set user initial
        if (initial) {
            userInitial.textContent = initial;
        } else if (userName) {
            userInitial.textContent = userName.charAt(0).toUpperCase();
        }
        
        // Create greeting
        const welcomeSection = document.querySelector('.welcome-section');
        if (welcomeSection) {
            const h1 = welcomeSection.querySelector('h1');
            if (h1) {
                const firstName = userName.split(' ')[0];
                h1.textContent = `Welcome back, ${firstName}!`;
            }
        }
    };
    
    // Smooth scrolling for navigation links
    const initSmoothScroll = () => {
        const navLinks = document.querySelectorAll('.nav-menu a');
        navLinks.forEach(link => {
            link.addEventListener('click', function(e) {
                const href = this.getAttribute('href');
                
                // Only apply to hash links (section links)
                if (href.startsWith('#')) {
                    e.preventDefault();
                    const targetId = href.substring(1);
                    const targetElement = document.getElementById(targetId);
                    
                    if (targetElement) {
                        // Smooth scroll to target
                        window.scrollTo({
                            top: targetElement.offsetTop - 80, // Account for header height
                            behavior: 'smooth'
                        });
                        
                        // Update active link
                        navLinks.forEach(navLink => navLink.classList.remove('active'));
                        this.classList.add('active');
                    }
                }
            });
        });
    };
    
    // Update active nav link on scroll
    const initScrollSpy = () => {
        const sections = document.querySelectorAll('.main-section');
        const navLinks = document.querySelectorAll('.nav-menu a');
        
        window.addEventListener('scroll', () => {
            let current = '';
            
            sections.forEach(section => {
                const sectionTop = section.offsetTop;
                const sectionHeight = section.clientHeight;
                
                if (pageYOffset >= sectionTop - 200) {
                    current = section.getAttribute('id');
                }
            });
            
            navLinks.forEach(link => {
                link.classList.remove('active');
                const href = link.getAttribute('href');
                if (href && href.substring(1) === current) {
                    link.classList.add('active');
                }
            });
        });
    };
    
    // Initialize components
    initializeUser();
    initSmoothScroll();
    initScrollSpy();
});