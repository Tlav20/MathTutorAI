/**
 * Simplified Animated Solution Viewer
 * Displays step-by-step solutions with animations
 */
class AnimatedSolution {
    constructor() {
        this.currentStep = 0;
        this.totalSteps = 0;
        this.steps = [];
        this.animationSpeed = 1000; // Default animation speed in ms
        this.animationTimer = null;
        this.isPlaying = false;
        this.container = null;
    }
    
    /**
     * Initialize the animated solution viewer
     * @param {string} containerId - ID of the container element
     * @param {Array} steps - Array of solution steps
     */
    init(containerId, steps) {
        // Clear any previous timer
        if (this.animationTimer) {
            clearTimeout(this.animationTimer);
            this.animationTimer = null;
        }
        
        this.container = document.getElementById(containerId);
        if (!this.container) {
            console.error(`Container element with ID '${containerId}' not found`);
            return;
        }
        
        this.steps = steps || [];
        this.totalSteps = this.steps.length;
        this.currentStep = 0;
        this.isPlaying = false;
        
        // Add CSS styles
        this.addStyles();
        
        // Create UI elements
        this.createUI();
        
        // Render the initial step
        if (this.totalSteps > 0) {
            this.renderStep(0);
        } else {
            this.container.innerHTML = '<div class="animated-solution-empty">No solution steps available</div>';
        }
    }
    
    /**
     * Add required CSS styles
     */
    addStyles() {
        if (!document.getElementById('animated-solution-styles')) {
            const styleEl = document.createElement('style');
            styleEl.id = 'animated-solution-styles';
            styleEl.textContent = `
                .animated-solution-container {
                    font-family: 'Segoe UI', Tahoma, sans-serif;
                    background-color: #f9f9f9;
                    border-radius: 8px;
                    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
                    padding: 20px;
                    margin: 20px 0;
                    max-width: 100%;
                }
                
                .animated-solution-area {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                    margin-bottom: 20px;
                }
                
                .animated-solution-step {
                    background-color: white;
                    border-radius: 8px;
                    padding: 20px;
                    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.05);
                    transition: opacity 0.5s, transform 0.5s;
                }
                
                .step-transitioning-out {
                    opacity: 0;
                    transform: translateY(20px);
                }
                
                .step-transitioning-in {
                    opacity: 1;
                    transform: translateY(0);
                }
                
                .step-explanation {
                    margin-bottom: 15px;
                    color: #333;
                    line-height: 1.5;
                }
                
                .step-equation {
                    font-family: monospace;
                    background-color: #f5f7fb;
                    padding: 12px;
                    border-radius: 6px;
                    margin-bottom: 15px;
                    text-align: center;
                    font-size: 18px;
                }
                
                .step-details {
                    color: #666;
                    margin-bottom: 15px;
                    line-height: 1.4;
                    font-size: 14px;
                }
                
                .step-result {
                    font-weight: 500;
                    color: #4c7af2;
                    border-top: 1px solid #eee;
                    padding-top: 10px;
                }
                
                .step-matrix {
                    font-family: monospace;
                    white-space: pre;
                    background-color: #f5f7fb;
                    padding: 12px;
                    border-radius: 6px;
                    margin: 15px 0;
                    overflow-x: auto;
                }
                
                .animated-solution-controls {
                    display: flex;
                    flex-direction: column;
                    gap: 10px;
                    margin-top: 20px;
                }
                
                .step-counter {
                    text-align: center;
                    font-size: a4px;
                    color: #666;
                    margin-bottom: 5px;
                }
                
                .control-buttons {
                    display: flex;
                    justify-content: center;
                    gap: 10px;
                }
                
                .control-btn {
                    background-color: white;
                    border: 1px solid #ddd;
                    border-radius: 8px;
                    padding: 8px 12px;
                    cursor: pointer;
                    transition: all 0.2s;
                }
                
                .control-btn:hover:not(:disabled) {
                    background-color: #f5f7fb;
                    border-color: #4c7af2;
                    transform: translateY(-2px);
                }
                
                .control-btn:disabled {
                    opacity: 0.5;
                    cursor: not-allowed;
                }
                
                .play-btn {
                    background-color: #4c7af2;
                    color: white;
                    border-color: #4c7af2;
                }
                
                .pause-btn {
                    background-color: #f0ad4e;
                    color: white;
                    border-color: #f0ad4e;
                }
                
                .progress-container {
                    width: 100%;
                    height: 6px;
                    background-color: #eee;
                    border-radius: 3px;
                    margin-top: 15px;
                    overflow: hidden;
                }
                
                .progress-bar {
                    height: 100%;
                    background-color: #4c7af2;
                    transition: width 0.3s;
                }
                
                .step-calculations {
                    margin: 15px 0;
                }
                
                .step-calculations ul {
                    list-style-type: none;
                    padding-left: 10px;
                    font-family: monospace;
                }
                
                .step-calculations li {
                    margin-bottom: 8px;
                }
            `;
            document.head.appendChild(styleEl);
        }
    }
    
    /**
     * Create the UI elements for the animated solution
     */
    createUI() {
        // Clear the container
        this.container.innerHTML = '';
        this.container.className = 'animated-solution-container';
        
        // Create solution area
        const solutionArea = document.createElement('div');
        solutionArea.className = 'animated-solution-area';
        this.container.appendChild(solutionArea);
        
        // Create step container
        const stepContainer = document.createElement('div');
        stepContainer.id = 'step-container';
        stepContainer.className = 'animated-solution-step';
        solutionArea.appendChild(stepContainer);
        
        // Create control panel
        const controls = document.createElement('div');
        controls.className = 'animated-solution-controls';
        
        // Create step counter
        const stepCounter = document.createElement('div');
        stepCounter.id = 'step-counter';
        stepCounter.className = 'step-counter';
        stepCounter.textContent = `Step 0 of ${this.totalSteps}`;
        controls.appendChild(stepCounter);
        
        // Create control buttons
        const controlButtons = document.createElement('div');
        controlButtons.className = 'control-buttons';
        
        // Previous button
        const prevBtn = document.createElement('button');
        prevBtn.id = 'prev-step-btn';
        prevBtn.className = 'control-btn';
        prevBtn.innerHTML = '&lt; Previous';
        prevBtn.title = 'Previous Step';
        prevBtn.addEventListener('click', () => this.showPreviousStep());
        
        // Play/Pause button
        const playBtn = document.createElement('button');
        playBtn.id = 'play-pause-btn';
        playBtn.className = 'control-btn play-btn';
        playBtn.innerHTML = 'Play';
        playBtn.title = 'Play Animation';
        playBtn.addEventListener('click', () => this.togglePlayPause());
        
        // Next button
        const nextBtn = document.createElement('button');
        nextBtn.id = 'next-step-btn';
        nextBtn.className = 'control-btn';
        nextBtn.innerHTML = 'Next &gt;';
        nextBtn.title = 'Next Step';
        nextBtn.addEventListener('click', () => this.showNextStep());
        
        // Append all controls
        controlButtons.appendChild(prevBtn);
        controlButtons.appendChild(playBtn);
        controlButtons.appendChild(nextBtn);
        controls.appendChild(controlButtons);
        
        // Add progress bar
        const progressBarContainer = document.createElement('div');
        progressBarContainer.className = 'progress-container';
        
        const progressBar = document.createElement('div');
        progressBar.id = 'progress-bar';
        progressBar.className = 'progress-bar';
        progressBar.style.width = '0%';
        
        progressBarContainer.appendChild(progressBar);
        controls.appendChild(progressBarContainer);
        
        // Append controls to container
        this.container.appendChild(controls);
    }
    
    /**
     * Render a specific step
     * @param {number} stepIndex - Index of the step to render
     */
    renderStep(stepIndex) {
        if (stepIndex < 0 || stepIndex >= this.totalSteps) return;
        
        this.currentStep = stepIndex;
        
        // Get step data
        const step = this.steps[stepIndex];
        
        // Update step counter
        const stepCounter = document.getElementById('step-counter');
        if (stepCounter) {
            stepCounter.textContent = `Step ${stepIndex + 1} of ${this.totalSteps}`;
        }
        
        // Update progress bar
        const progressBar = document.getElementById('progress-bar');
        if (progressBar) {
            const progressPercentage = ((stepIndex + 1) / this.totalSteps) * 100;
            progressBar.style.width = `${progressPercentage}%`;
        }
        
        // Update step container with animation
        const stepContainer = document.getElementById('step-container');
        
        if (stepContainer) {
            // Add transition class to create fade out effect
            stepContainer.classList.add('step-transitioning-out');
            
            // After the fade out, update content and fade in
            setTimeout(() => {
                // Update content
                this.renderStepContent(stepContainer, step);
                
                // Fade in new content
                stepContainer.classList.remove('step-transitioning-out');
                stepContainer.classList.add('step-transitioning-in');
                
                // After fade in complete, remove transition class
                setTimeout(() => {
                    stepContainer.classList.remove('step-transitioning-in');
                }, 500);
            }, 500);
        }
        
        // Update control buttons
        this.updateControlButtons();
    }
    
    /**
     * Render the content of a step
     * @param {HTMLElement} container - Container element
     * @param {Object} step - Step data
     */
    renderStepContent(container, step) {
        // Clear container
        container.innerHTML = '';
        
        // Create explanation element
        if (step.explanation) {
            const explanation = document.createElement('div');
            explanation.className = 'step-explanation';
            explanation.innerHTML = `<strong>Explanation:</strong> ${step.explanation}`;
            container.appendChild(explanation);
        }
        
        // Create equation element if available
        if (step.equation) {
            const equation = document.createElement('div');
            equation.className = 'step-equation';
            equation.textContent = step.equation;
            container.appendChild(equation);
        }
        
        // Create details element if available
        if (step.details) {
            const details = document.createElement('div');
            details.className = 'step-details';
            details.innerHTML = typeof step.details === 'string' ? step.details : JSON.stringify(step.details);
            container.appendChild(details);
        }
        
        // Create result element if available
        if (step.result) {
            const result = document.createElement('div');
            result.className = 'step-result';
            result.innerHTML = `<strong>Result:</strong> ${step.result}`;
            container.appendChild(result);
        }
        
        // If there's a matrix, display it
        if (step.matrix) {
            const matrixContainer = document.createElement('div');
            matrixContainer.className = 'step-matrix';
            
            // Format matrix as pre-formatted text
            let formattedMatrix;
            
            // Handle case where matrix is object with matrices A and B
            if (step.matrices && typeof step.matrices === 'object') {
                formattedMatrix = '';
                if (step.matrices.A) {
                    formattedMatrix += 'Matrix A:\n' + this.formatMatrix(step.matrices.A) + '\n\n';
                }
                if (step.matrices.B) {
                    formattedMatrix += 'Matrix B:\n' + this.formatMatrix(step.matrices.B);
                }
            } else {
                formattedMatrix = this.formatMatrix(step.matrix);
            }
            
            matrixContainer.textContent = formattedMatrix;
            container.appendChild(matrixContainer);
        }
        
        // If there are calculations, show them
        if (step.calculations) {
            const calculationsContainer = document.createElement('div');
            calculationsContainer.className = 'step-calculations';
            calculationsContainer.innerHTML = `<strong>Calculations:</strong>`;
            
            const calcList = document.createElement('ul');
            
            if (Array.isArray(step.calculations)) {
                step.calculations.forEach(calc => {
                    const calcItem = document.createElement('li');
                    calcItem.textContent = calc;
                    calcList.appendChild(calcItem);
                });
            } else {
                const calcItem = document.createElement('li');
                calcItem.textContent = step.calculations;
                calcList.appendChild(calcItem);
            }
            
            calculationsContainer.appendChild(calcList);
            container.appendChild(calculationsContainer);
        }
    }
    
    /**
     * Format a matrix for display
     * @param {Array<Array<number>>|Object} matrix - The matrix or object to format
     * @returns {string} - Formatted matrix string
     */
    formatMatrix(matrix) {
        // If it's not provided or empty
        if (!matrix) return '';
        
        // Handle case where matrix is in format {A: [...], B: [...]}
        if (typeof matrix === 'object' && !Array.isArray(matrix)) {
            let result = '';
            for (const key in matrix) {
                if (Array.isArray(matrix[key])) {
                    result += `Matrix ${key}:\n`;
                    result += this.formatMatrix(matrix[key]) + '\n\n';
                }
            }
            return result;
        }
        
        // If it's not an array, convert to string
        if (!Array.isArray(matrix)) {
            return matrix.toString();
        }
        
        // If it's an empty array
        if (matrix.length === 0) return '[]';
        
        // Format the matrix
        const rows = matrix.map(row => {
            // If row is not an array, convert to string
            if (!Array.isArray(row)) return row.toString();
            
            const formattedRow = row.map(val => {
                if (typeof val === 'number') {
                    return val.toFixed(2).padStart(8);
                }
                return val.toString().padStart(8);
            });
            
            return '| ' + formattedRow.join(' ') + ' |';
        });
        
        return rows.join('\n');
    }
    
    /**
     * Move to next step in the animation
     */
    showNextStep() {
        if (this.currentStep < this.totalSteps - 1) {
            this.renderStep(this.currentStep + 1);
        }
    }
    
    /**
     * Move to previous step in the animation
     */
    showPreviousStep() {
        if (this.currentStep > 0) {
            this.renderStep(this.currentStep - 1);
        }
    }
    
    /**
     * Toggle play/pause animation
     */
    togglePlayPause() {
        if (this.isPlaying) {
            this.stopAnimation();
        } else {
            this.startAnimation();
        }
    }
    
    /**
     * Start the animation
     */
    startAnimation() {
        // If we're at the end, go back to the beginning
        if (this.currentStep >= this.totalSteps - 1) {
            this.renderStep(0);
        }
        
        this.isPlaying = true;
        
        // Update play button
        const playBtn = document.getElementById('play-pause-btn');
        if (playBtn) {
            playBtn.innerHTML = 'Pause';
            playBtn.title = 'Pause Animation';
            playBtn.classList.remove('play-btn');
            playBtn.classList.add('pause-btn');
        }
        
        // Schedule next step
        this.animationTimer = setTimeout(() => {
            this.showNextStep();
            
            // If not at the end, continue animation
            if (this.currentStep < this.totalSteps - 1) {
                this.startAnimation();
            } else {
                this.stopAnimation();
            }
        }, this.animationSpeed);
    }
    
    /**
     * Stop the animation
     */
    stopAnimation() {
        this.isPlaying = false;
        
        // Clear timer
        if (this.animationTimer) {
            clearTimeout(this.animationTimer);
            this.animationTimer = null;
        }
        
        // Update play button
        const playBtn = document.getElementById('play-pause-btn');
        if (playBtn) {
            playBtn.innerHTML = 'Play';
            playBtn.title = 'Play Animation';
            playBtn.classList.remove('pause-btn');
            playBtn.classList.add('play-btn');
        }
    }
    
    /**
     * Update control buttons state
     */
    updateControlButtons() {
        const prevBtn = document.getElementById('prev-step-btn');
        const nextBtn = document.getElementById('next-step-btn');
        
        if (prevBtn) {
            prevBtn.disabled = this.currentStep <= 0;
        }
        
        if (nextBtn) {
            nextBtn.disabled = this.currentStep >= this.totalSteps - 1;
        }
    }
}

/**
 * Simple Math Parser for natural language input
 */
class MathParser {
    constructor() {
        // Set up basic patterns for different math problem types
        this.patterns = {
            algebra: [
                { regex: /solve\s+for\s+([a-zA-Z])\s*(?:in|:)?\s*(.*)/i, type: 'algebraEquation' },
                { regex: /find\s+([a-zA-Z])\s*(?:in|:)?\s*(.*)/i, type: 'algebraEquation' }
            ],
            matrix: [
                { regex: /(?:calculate|find)\s+(?:the)?\s*determinant\s+of\s*(.*)/i, type: 'matrixDeterminant' },
                { regex: /multiply\s+(?:the)?\s*matrices\s*(.*)\s*and\s*(.*)/i, type: 'matrixMultiplication' }
            ]
        };
    }
    
    /**
     * Parse natural language query to structured problem
     * @param {string} query - Natural language query
     * @returns {Object} - Parsed problem data
     */
    parseQuery(query) {
        // Clean up query
        query = query.trim();
        
        // Try to match query against patterns
        for (const [category, patterns] of Object.entries(this.patterns)) {
            for (const pattern of patterns) {
                const match = query.match(pattern.regex);
                if (match) {
                    // Process based on the pattern type
                    if (pattern.type === 'algebraEquation') {
                        const variable = match[1];
                        let equation = match[2];
                        
                        return {
                            type: 'algebra',
                            variable: variable,
                            equation: equation,
                            originalQuery: query
                        };
                    }
                    else if (pattern.type === 'matrixDeterminant') {
                        return {
                            type: 'matrix',
                            operation: 'determinant',
                            matrixExpression: match[1],
                            originalQuery: query
                        };
                    }
                    else if (pattern.type === 'matrixMultiplication') {
                        return {
                            type: 'matrix',
                            operation: 'multiply',
                            matrix1: match[1],
                            matrix2: match[2],
                            originalQuery: query
                        };
                    }
                }
            }
        }
        
        // If no pattern matches, return a generic type
        return {
            type: 'unknown',
            originalQuery: query,
            message: 'Could not parse the query into a specific math problem.'
        };
    }
}