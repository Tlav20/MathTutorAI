// MathTutor - Calculator Component

class Calculator {
    constructor() {
        this.currentInput = '0';
        this.currentExpression = '';
        this.lastResult = null;
        this.waitingForOperand = false;
        
        this.init();
    }

    init() {
        // Get DOM elements
        this.displayInput = document.getElementById('calc-input');
        this.displayResult = document.getElementById('calc-result');
        
        if (!this.displayInput || !this.displayResult) return;
        
        // Add event listeners for calculator buttons
        const buttons = document.querySelectorAll('.calc-btn');
        buttons.forEach(button => {
            button.addEventListener('click', (e) => {
                const target = e.target.closest('.calc-btn');
                if (!target) return;
                
                const action = target.dataset.action;
                const value = target.dataset.value;
                
                if (action) {
                    this.handleAction(action);
                } else if (value) {
                    this.handleInput(value);
                }
            });
        });
        
        // Add keyboard support
        document.addEventListener('keydown', (e) => {
            // Only process if calculator is in view
            const calculatorSection = document.getElementById('calculator-section');
            if (!calculatorSection) return;
            
            const isInView = calculatorSection.getBoundingClientRect().top < window.innerHeight;
            if (!isInView) return;
            
            if (e.key >= '0' && e.key <= '9') {
                this.handleInput(e.key);
            } else if (e.key === '.') {
                this.handleInput('.');
            } else if (e.key === '+') {
                this.handleAction('add');
            } else if (e.key === '-') {
                this.handleAction('subtract');
            } else if (e.key === '*') {
                this.handleAction('multiply');
            } else if (e.key === '/') {
                this.handleAction('divide');
            } else if (e.key === 'Enter' || e.key === '=') {
                this.handleAction('equals');
            } else if (e.key === 'Escape') {
                this.handleAction('clear');
            } else if (e.key === 'Backspace') {
                this.handleAction('backspace');
            }
        });
    }

    handleInput(value) {
        const isNumber = !isNaN(parseFloat(value)) && isFinite(value);
        const isDecimal = value === '.';
        
        if (this.waitingForOperand) {
            this.currentInput = isNumber || isDecimal ? value : '0';
            this.waitingForOperand = false;
        } else {
            // Handle decimal point
            if (isDecimal && this.currentInput.includes('.')) {
                return; // Prevent multiple decimal points
            }
            
            // Handle leading zero
            if (this.currentInput === '0' && isNumber) {
                this.currentInput = value;
            } else {
                this.currentInput += value;
            }
        }
        
        this.updateDisplay();
    }

    handleAction(action) {
        switch (action) {
            case 'add':
            case 'subtract':
            case 'multiply':
            case 'divide':
                this.handleOperator(action);
                break;
            case 'equals':
                this.calculateResult();
                break;
            case 'clear':
                this.clearCalculator();
                break;
            case 'backspace':
                this.handleBackspace();
                break;
        }
    }

    handleOperator(operator) {
        const operatorSymbols = {
            add: '+',
            subtract: '-',
            multiply: '×',
            divide: '÷'
        };
        
        const operatorSymbol = operatorSymbols[operator];
        const currentValue = parseFloat(this.currentInput);
        
        if (this.currentExpression === '') {
            // First operator in expression
            this.currentExpression = `${currentValue} ${operatorSymbol} `;
        } else if (this.waitingForOperand) {
            // Replace previous operator
            this.currentExpression = this.currentExpression.slice(0, -2) + `${operatorSymbol} `;
        } else {
            // Continue building expression
            this.currentExpression += `${currentValue} ${operatorSymbol} `;
            this.calculateIntermediateResult();
        }
        
        this.waitingForOperand = true;
        this.updateDisplay();
    }

    calculateIntermediateResult() {
        try {
            // Convert display operators to JavaScript operators
            let expressionToEval = this.currentExpression
                .replace(/×/g, '*')
                .replace(/÷/g, '/')
                .slice(0, -2); // Remove trailing operator and space
            
            const result = eval(expressionToEval);
            this.lastResult = result;
            this.displayResult.textContent = `= ${this.formatNumber(result)}`;
        } catch (error) {
            console.error('Calculator error:', error);
            this.displayResult.textContent = 'Error';
        }
    }

    calculateResult() {
        if (this.currentExpression === '' || this.waitingForOperand) return;
        
        try {
            // Add current input to expression
            let expressionToEval = this.currentExpression + this.currentInput;
            
            // Convert display operators to JavaScript operators
            expressionToEval = expressionToEval
                .replace(/×/g, '*')
                .replace(/÷/g, '/');
            
            const result = eval(expressionToEval);
            this.lastResult = result;
            
            // Update display
            this.displayResult.textContent = `= ${this.formatNumber(result)}`;
            
            // Reset for next calculation
            this.currentInput = result.toString();
            this.currentExpression = '';
            this.waitingForOperand = true;
        } catch (error) {
            console.error('Calculator error:', error);
            this.displayResult.textContent = 'Error';
        }
    }

    clearCalculator() {
        this.currentInput = '0';
        this.currentExpression = '';
        this.lastResult = null;
        this.waitingForOperand = false;
        this.updateDisplay();
    }

    handleBackspace() {
        if (this.waitingForOperand) return;
        
        if (this.currentInput.length > 1) {
            this.currentInput = this.currentInput.slice(0, -1);
        } else {
            this.currentInput = '0';
        }
        
        this.updateDisplay();
    }

    updateDisplay() {
        this.displayInput.textContent = this.formatNumber(this.currentInput);
        
        // Update result display based on state
        if (this.waitingForOperand) {
            // Show expression so far
            this.displayResult.textContent = this.currentExpression;
        } else if (this.lastResult !== null && this.currentExpression !== '') {
            // Show running calculation
            this.displayResult.textContent = `${this.currentExpression}${this.formatNumber(this.currentInput)}`;
        } else {
            // Clear result display when starting fresh
            this.displayResult.textContent = '';
        }
    }

    formatNumber(num) {
        // Convert to string if not already
        const numStr = num.toString();
        
        // Check if it's a decimal number
        if (numStr.includes('.')) {
            return numStr;
        }
        
        // Add commas for thousands separators
        return parseFloat(numStr).toLocaleString('en-US');
    }
}

// Initialize the Calculator when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const calculator = new Calculator();
});