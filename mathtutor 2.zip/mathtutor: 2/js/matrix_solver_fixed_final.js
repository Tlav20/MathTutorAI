/**
 * Enhanced matrix and linear algebra solver
 * Handles operations on matrices and systems of linear equations
 */
class MatrixSolver {
    /**
     * Create a matrix from a string representation
     * @param {string} matrixStr - String representation of a matrix (e.g., "[[1,2],[3,4]]")
     * @returns {Array<Array<number>>} - 2D array representing the matrix
     */
    static parseMatrix(matrixStr) {
        try {
            return JSON.parse(matrixStr.replace(/\s+/g, ''));
        } catch (error) {
            throw new Error('Invalid matrix format. Use format like "[[1,2],[3,4]]"');
        }
    }
    
    /**
     * Format a matrix for display
     * @param {Array<Array<number>>} matrix - The matrix to format
     * @returns {string} - Formatted matrix string
     */
    static formatMatrix(matrix) {
        if (!matrix || matrix.length === 0) return '[]';
        
        // Get the maximum width needed for each column
        const columnWidths = [];
        for (let j = 0; j < matrix[0].length; j++) {
            const columnValues = matrix.map(row => row[j]);
            const maxWidth = columnValues.reduce((max, val) => {
                const len = (typeof val === 'number' ? 
                    (Math.abs(val) < 0.0001 && val !== 0 ? val.toExponential(2) : val.toFixed(4)) : 
                    val.toString()).length;
                return Math.max(max, len);
            }, 0);
            columnWidths.push(maxWidth);
        }
        
        // Format each row
        const formattedRows = matrix.map(row => {
            const formattedRow = row.map((val, j) => {
                const strVal = typeof val === 'number' ? 
                    (Math.abs(val) < 0.0001 && val !== 0 ? val.toExponential(2) : val.toFixed(4)) : 
                    val.toString();
                return strVal.padStart(columnWidths[j]);
            });
            return '| ' + formattedRow.join(' ') + ' |';
        });
        
        return formattedRows.join('\n');
    }
    
    /**
     * Add two matrices
     * @param {Array<Array<number>>} matrixA - First matrix
     * @param {Array<Array<number>>} matrixB - Second matrix
     * @returns {Object} - Solution object with steps
     */
    static addMatrices(matrixA, matrixB) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the original matrices:',
            matrices: {
                A: matrixA,
                B: matrixB
            }
        });
        
        // Check if dimensions match
        if (matrixA.length !== matrixB.length || matrixA[0].length !== matrixB[0].length) {
            steps.push({
                explanation: 'Matrices cannot be added - dimensions do not match.',
                error: true
            });
            
            return {
                error: 'Matrix dimensions do not match',
                steps: steps
            };
        }
        
        const result = [];
        for (let i = 0; i < matrixA.length; i++) {
            const row = [];
            for (let j = 0; j < matrixA[0].length; j++) {
                row.push(matrixA[i][j] + matrixB[i][j]);
            }
            result.push(row);
        }
        
        steps.push({
            explanation: 'Add corresponding elements from both matrices:',
            details: 'For each position (i,j), calculate A[i,j] + B[i,j]'
        });
        
        steps.push({
            explanation: 'Result matrix:',
            matrix: result
        });
        
        return {
            result: result,
            steps: steps
        };
    }
    
    /**
     * Subtract matrix B from matrix A
     * @param {Array<Array<number>>} matrixA - First matrix
     * @param {Array<Array<number>>} matrixB - Second matrix
     * @returns {Object} - Solution object with steps
     */
    static subtractMatrices(matrixA, matrixB) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the original matrices:',
            matrices: {
                A: matrixA,
                B: matrixB
            }
        });
        
        // Check if dimensions match
        if (matrixA.length !== matrixB.length || matrixA[0].length !== matrixB[0].length) {
            steps.push({
                explanation: 'Matrices cannot be subtracted - dimensions do not match.',
                error: true
            });
            
            return {
                error: 'Matrix dimensions do not match',
                steps: steps
            };
        }
        
        const result = [];
        for (let i = 0; i < matrixA.length; i++) {
            const row = [];
            for (let j = 0; j < matrixA[0].length; j++) {
                row.push(matrixA[i][j] - matrixB[i][j]);
            }
            result.push(row);
        }
        
        steps.push({
            explanation: 'Subtract corresponding elements:',
            details: 'For each position (i,j), calculate A[i,j] - B[i,j]'
        });
        
        steps.push({
            explanation: 'Result matrix:',
            matrix: result
        });
        
        return {
            result: result,
            steps: steps
        };
    }
    
    /**
     * Multiply two matrices
     * @param {Array<Array<number>>} matrixA - First matrix
     * @param {Array<Array<number>>} matrixB - Second matrix
     * @returns {Object} - Solution object with steps
     */
    static multiplyMatrices(matrixA, matrixB) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the original matrices:',
            matrices: {
                A: matrixA,
                B: matrixB
            }
        });
        
        // Check if dimensions are compatible for multiplication
        if (matrixA[0].length !== matrixB.length) {
            steps.push({
                explanation: 'Matrices cannot be multiplied - incompatible dimensions.',
                details: `For matrix multiplication A×B, the number of columns in A (${matrixA[0].length}) must equal the number of rows in B (${matrixB.length}).`,
                error: true
            });
            
            return {
                error: 'Incompatible matrix dimensions for multiplication',
                steps: steps
            };
        }
        
        const result = [];
        const rowsA = matrixA.length;
        const colsA = matrixA[0].length;
        const colsB = matrixB[0].length;
        
        // Initialize result matrix with zeros
        for (let i = 0; i < rowsA; i++) {
            result.push(Array(colsB).fill(0));
        }
        
        // Create step-by-step calculation details
        const calculations = [];
        
        // Perform matrix multiplication
        for (let i = 0; i < rowsA; i++) {
            for (let j = 0; j < colsB; j++) {
                let sum = 0;
                const elementCalculation = [];
                
                for (let k = 0; k < colsA; k++) {
                    sum += matrixA[i][k] * matrixB[k][j];
                    elementCalculation.push(`(${matrixA[i][k]} × ${matrixB[k][j]})`);
                }
                
                result[i][j] = sum;
                calculations.push(`C[${i+1},${j+1}] = ${elementCalculation.join(' + ')} = ${sum}`);
            }
        }
        
        steps.push({
            explanation: 'Multiply matrices using the formula:',
            details: 'C[i,j] = sum(A[i,k] × B[k,j]) for all k'
        });
        
        steps.push({
            explanation: 'Detailed calculations:',
            calculations: calculations
        });
        
        steps.push({
            explanation: 'Result matrix:',
            matrix: result
        });
        
        return {
            result: result,
            steps: steps
        };
    }
    
    /**
     * Calculate the determinant of a matrix
     * @param {Array<Array<number>>} matrix - The matrix
     * @returns {Object} - Solution object with steps
     */
    static determinant(matrix) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the original matrix:',
            matrix: matrix
        });
        
        // Check if matrix is square
        const rows = matrix.length;
        for (let i = 0; i < rows; i++) {
            if (matrix[i].length !== rows) {
                steps.push({
                    explanation: 'Cannot calculate determinant - matrix is not square.',
                    error: true
                });
                
                return {
                    error: 'Matrix must be square to calculate determinant',
                    steps: steps
                };
            }
        }
        
        // Handle 1x1 matrix
        if (rows === 1) {
            steps.push({
                explanation: 'For a 1×1 matrix, the determinant is simply the single element.',
                result: matrix[0][0]
            });
            
            return {
                result: matrix[0][0],
                steps: steps
            };
        }
        
        // Handle 2x2 matrix
        if (rows === 2) {
            const det = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
            
            steps.push({
                explanation: 'For a 2×2 matrix, use the formula:',
                details: 'det(A) = A[1,1]×A[2,2] - A[1,2]×A[2,1]'
            });
            
            steps.push({
                explanation: `det(A) = (${matrix[0][0]} × ${matrix[1][1]}) - (${matrix[0][1]} × ${matrix[1][0]})`,
                result: det
            });
            
            return {
                result: det,
                steps: steps
            };
        }
        
        // Handle 3x3 and larger matrices using cofactor expansion
        let det = 0;
        let sign = 1;
        
        steps.push({
            explanation: 'For a larger matrix, we use cofactor expansion along the first row:',
            details: 'det(A) = sum((-1)^(1+j) × A[1,j] × det(Minor(A,1,j))) for all j'
        });
        
        const cofactorSteps = [];
        
        for (let j = 0; j < rows; j++) {
            // Skip calculation if element is 0
            if (matrix[0][j] === 0) {
                cofactorSteps.push(`Since A[1,${j+1}] = 0, this term is 0.`);
                continue;
            }
            
            // Calculate minor
            const minor = [];
            for (let i = 1; i < rows; i++) {
                const minorRow = [];
                for (let k = 0; k < rows; k++) {
                    if (k !== j) {
                        minorRow.push(matrix[i][k]);
                    }
                }
                minor.push(minorRow);
            }
            
            // Calculate determinant of minor recursively
            const minorDet = this.determinantValue(minor);
            
            // Calculate term for cofactor expansion
            const term = sign * matrix[0][j] * minorDet;
            det += term;
            
            cofactorSteps.push(`Term ${j+1}: (${sign}) × ${matrix[0][j]} × det(Minor) = ${term}`);
            
            sign *= -1;
        }
        
        steps.push({
            explanation: 'Cofactor expansion steps:',
            details: cofactorSteps
        });
        
        steps.push({
            explanation: 'Adding all terms:',
            result: det
        });
        
        return {
            result: det,
            steps: steps
        };
    }
    
    /**
     * Helper function to calculate determinant value (without steps)
     * @param {Array<Array<number>>} matrix - The matrix
     * @returns {number} - Determinant value
     */
    static determinantValue(matrix) {
        const rows = matrix.length;
        
        // Base cases
        if (rows === 1) return matrix[0][0];
        if (rows === 2) return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        
        // Recursive case
        let det = 0;
        let sign = 1;
        
        for (let j = 0; j < rows; j++) {
            // Skip calculation if element is 0
            if (matrix[0][j] === 0) {
                sign *= -1;
                continue;
            }
            
            // Calculate minor
            const minor = [];
            for (let i = 1; i < rows; i++) {
                const minorRow = [];
                for (let k = 0; k < rows; k++) {
                    if (k !== j) {
                        minorRow.push(matrix[i][k]);
                    }
                }
                minor.push(minorRow);
            }
            
            // Recursive call
            det += sign * matrix[0][j] * this.determinantValue(minor);
            sign *= -1;
        }
        
        return det;
    }
    
    /**
     * Calculate matrix inverse
     * @param {Array<Array<number>>} matrix - The matrix
     * @returns {Object} - Solution object with steps
     */
    static inverseMatrix(matrix) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the original matrix:',
            matrix: matrix
        });
        
        // Check if matrix is square
        const n = matrix.length;
        for (let i = 0; i < n; i++) {
            if (matrix[i].length !== n) {
                steps.push({
                    explanation: 'Cannot calculate inverse - matrix is not square.',
                    error: true
                });
                
                return {
                    error: 'Matrix must be square to calculate inverse',
                    steps: steps
                };
            }
        }
        
        // Calculate determinant
        const detResult = this.determinant(matrix);
        
        if (detResult.error) {
            return {
                error: detResult.error,
                steps: steps.concat(detResult.steps)
            };
        }
        
        const det = detResult.result;
        
        steps.push({
            explanation: 'Calculate the determinant:',
            result: det
        });
        
        // Check if matrix is invertible
        if (Math.abs(det) < 1e-10) {
            steps.push({
                explanation: 'The determinant is zero (or very close to zero), so the matrix is not invertible.',
                error: true
            });
            
            return {
                error: 'Matrix is singular (not invertible)',
                steps: steps
            };
        }
        
        // For 2x2 matrix, we can use a direct formula
        if (n === 2) {
            const result = [
                [matrix[1][1] / det, -matrix[0][1] / det],
                [-matrix[1][0] / det, matrix[0][0] / det]
            ];
            
            steps.push({
                explanation: 'For a 2×2 matrix, use the formula:',
                details: `A^(-1) = (1/det(A)) × [ [a22, -a12], [-a21, a11] ]`
            });
            
            steps.push({
                explanation: 'Invert the matrix:',
                matrix: result
            });
            
            return {
                result: result,
                steps: steps
            };
        }
        
        // For larger matrices, we use the adjugate method
        steps.push({
            explanation: 'For a larger matrix, we need to calculate the adjugate matrix:',
            details: 'adj(A)[j,i] = (-1)^(i+j) × det(Minor(A,i,j))'
        });
        
        // Calculate the cofactor matrix
        const cofactors = [];
        for (let i = 0; i < n; i++) {
            cofactors.push([]);
            for (let j = 0; j < n; j++) {
                // Calculate minor
                const minor = [];
                for (let r = 0; r < n; r++) {
                    if (r !== i) {
                        const minorRow = [];
                        for (let c = 0; c < n; c++) {
                            if (c !== j) {
                                minorRow.push(matrix[r][c]);
                            }
                        }
                        minor.push(minorRow);
                    }
                }
                
                // Calculate minor determinant
                const minorDet = this.determinantValue(minor);
                const sign = ((i + j) % 2 === 0) ? 1 : -1;
                cofactors[i][j] = sign * minorDet;
            }
        }
        
        steps.push({
            explanation: 'Calculate the cofactor matrix:',
            matrix: cofactors
        });
        
        // Calculate the adjugate (transpose of cofactor matrix)
        const adjugate = [];
        for (let i = 0; i < n; i++) {
            adjugate.push([]);
            for (let j = 0; j < n; j++) {
                adjugate[i][j] = cofactors[j][i];
            }
        }
        
        steps.push({
            explanation: 'Calculate the adjugate matrix (transpose of cofactor matrix):',
            matrix: adjugate
        });
        
        // Calculate the inverse
        const inverse = [];
        for (let i = 0; i < n; i++) {
            inverse.push([]);
            for (let j = 0; j < n; j++) {
                inverse[i][j] = adjugate[i][j] / det;
            }
        }
        
        steps.push({
            explanation: 'Calculate the inverse by dividing adjugate by determinant:',
            matrix: inverse
        });
        
        // Verify the inverse
        steps.push({
            explanation: 'We can verify the result by checking that A×A^(-1) ≈ I',
            details: 'Where I is the identity matrix'
        });
        
        return {
            result: inverse,
            steps: steps
        };
    }
    
    /**
     * Solve a system of linear equations using Gaussian elimination
     * @param {Array<Array<number>>} augmentedMatrix - The augmented matrix [A|b]
     * @returns {Object} - Solution object with steps
     */
    static solveLinearSystem(augmentedMatrix) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the augmented matrix [A|b]:',
            matrix: augmentedMatrix
        });
        
        // Make a deep copy of the augmented matrix for manipulation
        const mat = augmentedMatrix.map(row => [...row]);
        
        const rows = mat.length;
        const cols = mat[0].length;
        const n = cols - 1; // Number of variables
        
        if (rows < n) {
            steps.push({
                explanation: 'The system is underdetermined - there are fewer equations than variables.',
                details: 'Such systems typically have infinitely many solutions.'
            });
        }
        
        // Forward elimination (convert to row echelon form)
        steps.push({
            explanation: 'Perform forward elimination to convert the matrix to row echelon form:'
        });
        
        const eliminationSteps = [];
        
        for (let i = 0; i < rows; i++) {
            // Find pivot (the first non-zero element in the current row)
            let pivot = i;
            while (pivot < n && Math.abs(mat[i][pivot]) < 1e-10) {
                pivot++;
            }
            
            // If pivot is beyond last column, the row is all zeros (skip)
            if (pivot === n) continue;
            
            // Swap rows if necessary
            if (i !== pivot) {
                [mat[i], mat[pivot]] = [mat[pivot], mat[i]];
                eliminationSteps.push(`Swap rows ${i+1} and ${pivot+1}`);
                eliminationSteps.push(this.formatMatrix(mat));
            }
            
            // Make pivot element 1
            const pivotValue = mat[i][pivot];
            if (Math.abs(pivotValue - 1) > 1e-10) { // If not already 1
                for (let j = pivot; j < cols; j++) {
                    mat[i][j] /= pivotValue;
                }
                eliminationSteps.push(`Divide row ${i+1} by ${pivotValue}`);
                eliminationSteps.push(this.formatMatrix(mat));
            }
            
            // Eliminate other rows
            for (let k = 0; k < rows; k++) {
                if (k !== i && Math.abs(mat[k][pivot]) > 1e-10) {
                    const factor = mat[k][pivot];
                    for (let j = pivot; j < cols; j++) {
                        mat[k][j] -= factor * mat[i][j];
                    }
                    eliminationSteps.push(`Subtract ${factor} times row ${i+1} from row ${k+1}`);
                    eliminationSteps.push(this.formatMatrix(mat));
                }
            }
        }
        
        steps.push({
            explanation: 'Elimination steps:',
            details: eliminationSteps
        });
        
        steps.push({
            explanation: 'Row echelon form:',
            matrix: mat
        });
        
        // Back substitution
        steps.push({
            explanation: 'Perform back substitution to find the solution:'
        });
        
        // Check for inconsistent system
        for (let i = 0; i < rows; i++) {
            let allZeros = true;
            for (let j = 0; j < n; j++) {
                if (Math.abs(mat[i][j]) > 1e-10) {
                    allZeros = false;
                    break;
                }
            }
            
            if (allZeros && Math.abs(mat[i][n]) > 1e-10) {
                steps.push({
                    explanation: 'The system is inconsistent (no solution).',
                    details: `Row ${i+1} indicates 0 = ${mat[i][n]}, which is a contradiction.`,
                    error: true
                });
                
                return {
                    error: 'System is inconsistent (no solution)',
                    steps: steps
                };
            }
        }
        
        // Check for infinite solutions
        let pivotCount = 0;
        for (let i = 0; i < rows; i++) {
            for (let j = 0; j < n; j++) {
                if (Math.abs(mat[i][j]) > 1e-10) {
                    pivotCount++;
                    break;
                }
            }
        }
        
        if (pivotCount < n) {
            steps.push({
                explanation: 'The system has infinitely many solutions.',
                details: 'There are free variables that can take any value.'
            });
            
            return {
                result: 'Infinitely many solutions',
                steps: steps
            };
        }
        
        // Solve the system (assuming unique solution)
        const solution = Array(n).fill(0);
        
        for (let i = rows - 1; i >= 0; i--) {
            let pivotCol = 0;
            while (pivotCol < n && Math.abs(mat[i][pivotCol]) < 1e-10) {
                pivotCol++;
            }
            
            if (pivotCol === n) continue; // Skip rows of all zeros
            
            let sum = mat[i][n]; // The constant term
            
            for (let j = pivotCol + 1; j < n; j++) {
                sum -= mat[i][j] * solution[j];
            }
            
            solution[pivotCol] = sum / mat[i][pivotCol];
        }
        
        // Format solution
        const solutionSteps = [];
        for (let i = 0; i < n; i++) {
            solutionSteps.push(`x${i+1} = ${solution[i]}`);
        }
        
        steps.push({
            explanation: 'Solution:',
            details: solutionSteps
        });
        
        return {
            result: solution,
            steps: steps
        };
    }
    
    /**
     * Calculate eigenvalues and eigenvectors (for 2x2 and 3x3 matrices)
     * @param {Array<Array<number>>} matrix - The matrix
     * @returns {Object} - Solution object with steps
     */
    static eigenvalues(matrix) {
        const steps = [];
        
        steps.push({
            explanation: 'Start with the original matrix:',
            matrix: matrix
        });
        
        // Check if matrix is square
        const n = matrix.length;
        for (let i = 0; i < n; i++) {
            if (matrix[i].length !== n) {
                steps.push({
                    explanation: 'Cannot calculate eigenvalues - matrix is not square.',
                    error: true
                });
                
                return {
                    error: 'Matrix must be square to calculate eigenvalues',
                    steps: steps
                };
            }
        }
        
        // We'll implement eigenvalue calculation for 2x2 and 3x3 matrices
        // For larger matrices, numerical methods like QR algorithm would be needed
        
        if (n > 3) {
            steps.push({
                explanation: 'For matrices larger than 3×3, we need numerical methods.',
                details: 'This implementation supports up to 3×3 matrices.',
                error: true
            });
            
            return {
                error: 'Eigenvalue calculation for matrices larger than 3×3 is not implemented',
                steps: steps
            };
        }
        
        // Calculate the characteristic polynomial
        steps.push({
            explanation: 'Calculate the characteristic polynomial:',
            details: 'det(A - λI) = 0, where I is the identity matrix and λ is the eigenvalue'
        });
        
        if (n === 2) {
            // For 2x2 matrix, we can find eigenvalues directly using quadratic formula
            const a = 1; // Coefficient of λ²
            const b = -(matrix[0][0] + matrix[1][1]); // Coefficient of λ
            const c = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0]; // Constant term
            
            steps.push({
                explanation: 'For a 2×2 matrix, the characteristic polynomial is:',
                details: `λ² - (a₁₁ + a₂₂)λ + (a₁₁a₂₂ - a₁₂a₂₁) = 0`
            });
            
            steps.push({
                explanation: 'Substituting values:',
                details: `λ² + (${b})λ + ${c} = 0`
            });
            
            // Calculate discriminant
            const discriminant = b * b - 4 * a * c;
            
            steps.push({
                explanation: 'Using the quadratic formula:',
                details: `λ = (-b ± √(b² - 4ac)) / 2a = (${-b} ± √${discriminant}) / 2`
            });
            
            let eigenvalues = [];
            
            if (discriminant >= 0) {
                const sqrtDiscriminant = Math.sqrt(discriminant);
                const lambda1 = (-b + sqrtDiscriminant) / (2 * a);
                const lambda2 = (-b - sqrtDiscriminant) / (2 * a);
                
                eigenvalues = [lambda1, lambda2];
                
                steps.push({
                    explanation: 'The eigenvalues are:',
                    details: `λ₁ = ${lambda1}, λ₂ = ${lambda2}`
                });
            } else {
                const realPart = -b / (2 * a);
                const imaginaryPart = Math.sqrt(-discriminant) / (2 * a);
                
                steps.push({
                    explanation: 'The eigenvalues are complex:',
                    details: `λ₁ = ${realPart} + ${imaginaryPart}i, λ₂ = ${realPart} - ${imaginaryPart}i`
                });
                
                eigenvalues = [
                    { real: realPart, imaginary: imaginaryPart },
                    { real: realPart, imaginary: -imaginaryPart }
                ];
            }
            
            // Calculate eigenvectors for real eigenvalues
            if (discriminant >= 0) {
                steps.push({
                    explanation: 'Calculate eigenvectors for each eigenvalue:',
                    details: 'For each λ, solve (A - λI)v = 0'
                });
                
                const eigenvectors = [];
                
                for (let i = 0; i < eigenvalues.length; i++) {
                    const lambda = eigenvalues[i];
                    
                    // Create matrix A - λI
                    const matrixMinusLambdaI = [
                        [matrix[0][0] - lambda, matrix[0][1]],
                        [matrix[1][0], matrix[1][1] - lambda]
                    ];
                    
                    steps.push({
                        explanation: `For λ = ${lambda}:`,
                        details: `A - λI = ${this.formatMatrix(matrixMinusLambdaI)}`
                    });
                    
                    // For 2x2, we can find a non-zero solution directly
                    let eigenvector;
                    
                    if (Math.abs(matrixMinusLambdaI[0][0]) > 1e-10) {
                        eigenvector = [-matrixMinusLambdaI[0][1], matrixMinusLambdaI[0][0]];
                    } else if (Math.abs(matrixMinusLambdaI[1][0]) > 1e-10) {
                        eigenvector = [-matrixMinusLambdaI[1][1], matrixMinusLambdaI[1][0]];
                    } else if (Math.abs(matrixMinusLambdaI[0][1]) > 1e-10) {
                        eigenvector = [matrixMinusLambdaI[0][1], -matrixMinusLambdaI[0][0]];
                    } else {
                        eigenvector = [1, 0]; // Default if all elements are zero
                    }
                    
                    // Normalize the eigenvector
                    const norm = Math.sqrt(eigenvector[0] * eigenvector[0] + eigenvector[1] * eigenvector[1]);
                    eigenvector = [eigenvector[0] / norm, eigenvector[1] / norm];
                    
                    eigenvectors.push(eigenvector);
                    
                    steps.push({
                        explanation: `Eigenvector for λ = ${lambda}:`,
                        details: `v = [${eigenvector[0]}, ${eigenvector[1]}]`
                    });
                }
                
                return {
                    eigenvalues: eigenvalues,
                    eigenvectors: eigenvectors,
                    steps: steps
                };
            } else {
                // Complex eigenvalues case
                steps.push({
                    explanation: 'For complex eigenvalues, eigenvectors will also be complex.',
                    details: 'Complex eigenvector calculation is not implemented in this version.'
                });
                
                return {
                    eigenvalues: eigenvalues,
                    steps: steps
                };
            }
        }
        
        // For 3x3 matrix, we calculate the characteristic polynomial
        // and find its roots (either analytically or numerically)
        else if (n === 3) {
            steps.push({
                explanation: 'For a 3×3 matrix, we need to find the characteristic polynomial:',
                details: 'det(A - λI) = -λ³ + trace(A)λ² - ....'
            });
            
            // Calculate coefficients of the characteristic polynomial -λ³ + aλ² + bλ + c
            const trace = matrix[0][0] + matrix[1][1] + matrix[2][2];
            
            // Calculate the determinant of minors
            const minor1 = matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1];
            const minor2 = matrix[0][0] * matrix[2][2] - matrix[0][2] * matrix[2][0];
            const minor3 = matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
            
            // Second coefficient
            const a = trace;
            
            // Third coefficient (negative sum of determinants of principal minors)
            const b = -(minor1 + minor2 + minor3) + matrix[0][1] * matrix[1][0] + matrix[0][2] * matrix[2][0] + matrix[1][2] * matrix[2][1];
            
            // Fourth coefficient (determinant)
            const c = matrix[0][0] * minor1 - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0]) + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0]);
            
            steps.push({
                explanation: 'The characteristic polynomial is:',
                details: `-λ³ + ${a}λ² + ${b}λ + ${c} = 0`
            });
            
            steps.push({
                explanation: 'Finding the roots of this cubic equation analytically is complex.',
                details: 'In practice, numerical methods are often used for cubic and higher degree equations.'
            });
            
            return {
                polynomial: {
                    a: -1, // coefficient of λ³
                    b: a,  // coefficient of λ²
                    c: b,  // coefficient of λ
                    d: c   // constant term
                },
                steps: steps
            };
        }
    }
    
    /**
     * Solve a specific type of matrix or linear algebra problem
     * @param {string} problemType - Type of problem to solve
     * @param {Object} params - Parameters for the problem
     * @returns {Object} - Solution with steps
     */
    static solveMatrix(problemType, params) {
        switch (problemType.toLowerCase()) {
            case 'add':
                return this.addMatrices(params.matrixA, params.matrixB);
            
            case 'subtract':
                return this.subtractMatrices(params.matrixA, params.matrixB);
            
            case 'multiply':
                return this.multiplyMatrices(params.matrixA, params.matrixB);
            
            case 'determinant':
                return this.determinant(params.matrix);
            
            case 'inverse':
                return this.inverseMatrix(params.matrix);
            
            case 'system':
                return this.solveLinearSystem(params.augmentedMatrix);
            
            case 'eigenvalues':
                return this.eigenvalues(params.matrix);
            
            default:
                return {
                    error: `Unsupported problem type: ${problemType}`,
                    steps: []
                };
        }
    }
    
    /**
     * Parse a natural language query and identify the matrix problem
     * @param {string} query - Natural language query
     * @returns {Object} - Identified problem type and parameters
     */
    static parseQuery(query) {
        const lowerQuery = query.toLowerCase();
        
        // Check for addition
        if (lowerQuery.includes('add') || lowerQuery.includes('sum') || lowerQuery.includes('plus')) {
            return { problemType: 'add' };
        }
        
        // Check for subtraction
        if (lowerQuery.includes('subtract') || lowerQuery.includes('minus') || lowerQuery.includes('difference')) {
            return { problemType: 'subtract' };
        }
        
        // Check for multiplication
        if (lowerQuery.includes('multiply') || lowerQuery.includes('product')) {
            return { problemType: 'multiply' };
        }
        
        // Check for determinant
        if (lowerQuery.includes('determinant') || lowerQuery.includes('det')) {
            return { problemType: 'determinant' };
        }
        
        // Check for inverse
        if (lowerQuery.includes('inverse') || lowerQuery.includes('invert')) {
            return { problemType: 'inverse' };
        }
        
        // Check for eigenvalues
        if (lowerQuery.includes('eigenvalue') || lowerQuery.includes('eigenvector')) {
            return { problemType: 'eigenvalues' };
        }
        
        // Check for system of equations
        if (lowerQuery.includes('system') || lowerQuery.includes('solve for') || 
            lowerQuery.includes('solve x') || lowerQuery.includes('linear equations')) {
            return { problemType: 'system' };
        }
        
        // Default to unknown
        return { problemType: 'unknown' };
    }
}