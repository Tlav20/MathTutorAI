// MathTutor - Notes Component

class Notes {
    constructor() {
        this.notes = [];
        this.currentNoteId = null;
        
        // DOM elements
        this.notesList = document.getElementById('notes-list');
        this.noteTitleInput = document.getElementById('note-title-input');
        this.noteContent = document.getElementById('note-content');
        this.newNoteBtn = document.getElementById('new-note-btn');
        this.saveNoteBtn = document.getElementById('save-note-btn');
        this.deleteNoteBtn = document.getElementById('delete-note-btn');
        
        this.init();
    }

    init() {
        if (!this.notesList) return;
        
        // Load notes from local storage
        this.loadNotes();
        
        // Render notes list
        this.renderNotesList();
        
        // Add event listeners
        this.addEventListeners();
    }

    loadNotes() {
        const savedNotes = localStorage.getItem('mathTutorNotes');
        if (savedNotes) {
            try {
                this.notes = JSON.parse(savedNotes);
            } catch (error) {
                console.error('Error loading notes:', error);
                this.notes = [];
            }
        }
    }

    saveNotesToStorage() {
        localStorage.setItem('mathTutorNotes', JSON.stringify(this.notes));
    }

    addEventListeners() {
        // New note button
        if (this.newNoteBtn) {
            this.newNoteBtn.addEventListener('click', () => this.createNewNote());
        }
        
        // Save note button
        if (this.saveNoteBtn) {
            this.saveNoteBtn.addEventListener('click', () => this.saveCurrentNote());
        }
        
        // Delete note button
        if (this.deleteNoteBtn) {
            this.deleteNoteBtn.addEventListener('click', () => this.deleteCurrentNote());
        }
        
        // Autosave on content change
        if (this.noteContent) {
            this.noteContent.addEventListener('input', () => {
                if (this.currentNoteId) {
                    this.autoSaveCurrentNote();
                }
            });
        }
        
        if (this.noteTitleInput) {
            this.noteTitleInput.addEventListener('input', () => {
                if (this.currentNoteId) {
                    this.autoSaveCurrentNote();
                }
            });
        }
    }

    renderNotesList() {
        if (!this.notesList) return;
        
        // Clear list first
        this.notesList.innerHTML = '';
        
        if (this.notes.length === 0) {
            // Show empty state
            this.notesList.innerHTML = `
                <div class="empty-notes">
                    <p>No notes yet. Create your first note!</p>
                </div>
            `;
            return;
        }
        
        // Sort notes by last modified date (newest first)
        const sortedNotes = [...this.notes].sort((a, b) => b.lastModified - a.lastModified);
        
        // Create note items
        sortedNotes.forEach(note => {
            const noteItem = document.createElement('div');
            noteItem.className = 'note-item';
            if (note.id === this.currentNoteId) {
                noteItem.classList.add('active');
            }
            
            noteItem.innerHTML = `
                <div class="note-title">${note.title || 'Untitled Note'}</div>
                <div class="note-date">${this.formatDate(note.lastModified)}</div>
            `;
            
            noteItem.addEventListener('click', () => this.openNote(note.id));
            
            this.notesList.appendChild(noteItem);
        });
    }

    createNewNote() {
        const newNote = {
            id: this.generateId(),
            title: 'Untitled Note',
            content: '',
            created: Date.now(),
            lastModified: Date.now()
        };
        
        // Add to notes array
        this.notes.unshift(newNote);
        
        // Save to storage
        this.saveNotesToStorage();
        
        // Update UI
        this.renderNotesList();
        this.openNote(newNote.id);
    }

    openNote(noteId) {
        // Find note
        const note = this.notes.find(n => n.id === noteId);
        if (!note) return;
        
        // Set current note
        this.currentNoteId = noteId;
        
        // Update editor fields
        if (this.noteTitleInput) {
            this.noteTitleInput.value = note.title || '';
        }
        
        if (this.noteContent) {
            this.noteContent.value = note.content || '';
        }
        
        // Update UI
        this.renderNotesList();
        
        // Focus on title input
        if (this.noteTitleInput) {
            this.noteTitleInput.focus();
        }
    }

    saveCurrentNote() {
        if (!this.currentNoteId) return;
        
        const title = this.noteTitleInput ? this.noteTitleInput.value.trim() : '';
        const content = this.noteContent ? this.noteContent.value : '';
        
        // Find current note
        const noteIndex = this.notes.findIndex(n => n.id === this.currentNoteId);
        if (noteIndex === -1) return;
        
        // Update note
        this.notes[noteIndex] = {
            ...this.notes[noteIndex],
            title: title || 'Untitled Note',
            content: content,
            lastModified: Date.now()
        };
        
        // Save to storage
        this.saveNotesToStorage();
        
        // Update UI
        this.renderNotesList();
        
        // Show confirmation
        this.showNotification('Note saved successfully!');
    }

    autoSaveCurrentNote() {
        if (!this.currentNoteId) return;
        
        const title = this.noteTitleInput ? this.noteTitleInput.value.trim() : '';
        const content = this.noteContent ? this.noteContent.value : '';
        
        // Find current note
        const noteIndex = this.notes.findIndex(n => n.id === this.currentNoteId);
        if (noteIndex === -1) return;
        
        // Update note
        this.notes[noteIndex] = {
            ...this.notes[noteIndex],
            title: title || 'Untitled Note',
            content: content,
            lastModified: Date.now()
        };
        
        // Save to storage
        this.saveNotesToStorage();
        
        // Update UI (just the list, not the editor)
        this.renderNotesList();
    }

    deleteCurrentNote() {
        if (!this.currentNoteId) return;
        
        // Confirm deletion
        if (!confirm('Are you sure you want to delete this note?')) {
            return;
        }
        
        // Find current note index
        const noteIndex = this.notes.findIndex(n => n.id === this.currentNoteId);
        if (noteIndex === -1) return;
        
        // Remove note
        this.notes.splice(noteIndex, 1);
        
        // Save to storage
        this.saveNotesToStorage();
        
        // Reset current note
        this.currentNoteId = null;
        
        // Clear editor
        if (this.noteTitleInput) {
            this.noteTitleInput.value = '';
        }
        
        if (this.noteContent) {
            this.noteContent.value = '';
        }
        
        // Update UI
        this.renderNotesList();
        
        // Show confirmation
        this.showNotification('Note deleted successfully!');
        
        // Open first note if available
        if (this.notes.length > 0) {
            this.openNote(this.notes[0].id);
        }
    }

    showNotification(message) {
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'notification';
        notification.textContent = message;
        
        // Add to page
        document.body.appendChild(notification);
        
        // Show with animation
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        // Remove after delay
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                document.body.removeChild(notification);
            }, 300);
        }, 3000);
    }

    generateId() {
        return 'note_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
    }

    formatDate(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleDateString('en-US', { 
            month: 'long', 
            day: 'numeric', 
            year: 'numeric' 
        });
    }
}

// Initialize the Notes component when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const notes = new Notes();
});