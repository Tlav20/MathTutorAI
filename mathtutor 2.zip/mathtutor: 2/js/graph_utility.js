// MathTutor - Graphing Utility for Math Solver

class GraphUtility {
    /**
     * Create a graph for an algebraic equation
     * @param {string} canvasId - The ID of the canvas element
     * @param {Object} equation - The equation object with variable and solution
     * @param {string} originalEquation - The original equation string
     */
    static createEquationGraph(canvasId, equation, originalEquation) {
        const canvas = document.getElementById(canvasId);
        if (!canvas) return;
        
        const ctx = canvas.getContext('2d');
        
        // Clear canvas
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Set canvas dimensions
        canvas.width = canvas.clientWidth;
        canvas.height = canvas.clientHeight;
        
        // Extract variable and solution
        const { variable, solution } = equation;
        
        // Try to parse the equation to determine if it's linear or not
        const equationType = this.determineEquationType(originalEquation);
        
        if (equationType === 'linear') {
            this.drawLinearEquation(ctx, canvas, variable, solution, originalEquation);
        } else {
            // Default fallback - just show the solution point
            this.drawSolutionPoint(ctx, canvas, variable, solution);
        }
    }
    
    /**
     * Determine the type of equation (linear, quadratic, etc)
     * @param {string} equation - The equation string
     * @returns {string} - The equation type
     */
    static determineEquationType(equation) {
        // Basic detection - this can be expanded for more advanced equations
        if (equation.includes('^2') || equation.includes('²')) {
            return 'quadratic';
        } else {
            return 'linear';
        }
    }
    
    /**
     * Draw a linear equation graph
     * @param {CanvasRenderingContext2D} ctx - Canvas context
     * @param {HTMLCanvasElement} canvas - Canvas element
     * @param {string} variable - The variable name
     * @param {number} solution - The solution value
     * @param {string} originalEquation - The original equation string
     */
    static drawLinearEquation(ctx, canvas, variable, solution, originalEquation) {
        // Canvas dimensions
        const width = canvas.width;
        const height = canvas.height;
        
        // Graph settings
        const padding = 40;
        const axisColor = '#999';
        const gridColor = '#eee';
        const lineColor = '#4c7af2';
        const pointColor = '#e74c3c';
        
        // Determine graph range
        const solutionValue = parseFloat(solution);
        const xMin = Math.floor(solutionValue - 5);
        const xMax = Math.ceil(solutionValue + 5);
        const yMin = -5;
        const yMax = 5;
        
        // Scale factors
        const xScale = (width - 2 * padding) / (xMax - xMin);
        const yScale = (height - 2 * padding) / (yMax - yMin);
        
        // Functions to convert between coordinate systems
        const xToCanvas = (x) => padding + (x - xMin) * xScale;
        const yToCanvas = (y) => height - padding - (y - yMin) * yScale;
        
        // Draw grid
        ctx.strokeStyle = gridColor;
        ctx.lineWidth = 1;
        
        // Vertical grid lines
        for (let x = Math.ceil(xMin); x <= xMax; x++) {
            ctx.beginPath();
            ctx.moveTo(xToCanvas(x), yToCanvas(yMin));
            ctx.lineTo(xToCanvas(x), yToCanvas(yMax));
            ctx.stroke();
            
            // X-axis labels
            ctx.fillStyle = '#666';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(x, xToCanvas(x), yToCanvas(yMin) + 20);
        }
        
        // Horizontal grid lines
        for (let y = Math.ceil(yMin); y <= yMax; y++) {
            ctx.beginPath();
            ctx.moveTo(xToCanvas(xMin), yToCanvas(y));
            ctx.lineTo(xToCanvas(xMax), yToCanvas(y));
            ctx.stroke();
            
            // Y-axis labels
            if (y !== 0) { // Skip 0 to avoid overlapping with x-axis
                ctx.fillStyle = '#666';
                ctx.font = '12px Arial';
                ctx.textAlign = 'right';
                ctx.fillText(y, xToCanvas(xMin) - 10, yToCanvas(y) + 5);
            }
        }
        
        // Draw axes
        ctx.strokeStyle = axisColor;
        ctx.lineWidth = 2;
        
        // X-axis
        ctx.beginPath();
        ctx.moveTo(xToCanvas(xMin), yToCanvas(0));
        ctx.lineTo(xToCanvas(xMax), yToCanvas(0));
        ctx.stroke();
        
        // Y-axis
        ctx.beginPath();
        ctx.moveTo(xToCanvas(0), yToCanvas(yMin));
        ctx.lineTo(xToCanvas(0), yToCanvas(yMax));
        ctx.stroke();
        
        // Axis labels
        ctx.fillStyle = '#333';
        ctx.font = 'bold 14px Arial';
        ctx.textAlign = 'center';
        
        // X-axis label
        ctx.fillText(variable, xToCanvas(xMax) + 15, yToCanvas(0));
        
        // Y-axis label
        ctx.save();
        ctx.translate(xToCanvas(0) - 25, yToCanvas(yMax) - 15);
        ctx.rotate(-Math.PI / 2);
        ctx.fillText('y', 0, 0);
        ctx.restore();
        
        // Try to draw a line representing the equation
        try {
            // Very simple parser for linear equations
            // This is just a basic implementation and would need to be expanded for real use
            let slope = 1;
            let yIntercept = 0;
            
            // Using the fact that we know the solution point (solution, 0)
            // Assume the equation is in the form ax + b = cx + d
            // At the solution point, we have a*solution + b = c*solution + d
            // So (a-c)*solution + (b-d) = 0
            // Let's try a simple approach: assume the line crosses y=0 at x=solution
            // and has a slope of 1 (this is just for visualization)
            
            // Draw line
            ctx.strokeStyle = lineColor;
            ctx.lineWidth = 2;
            ctx.beginPath();
            
            // Draw line from left to right of canvas
            const y1 = slope * (xMin - solutionValue);  // y = m(x - x0) since y0 = 0
            const y2 = slope * (xMax - solutionValue);
            
            ctx.moveTo(xToCanvas(xMin), yToCanvas(y1));
            ctx.lineTo(xToCanvas(xMax), yToCanvas(y2));
            ctx.stroke();
            
            // Draw solution point
            ctx.fillStyle = pointColor;
            ctx.beginPath();
            ctx.arc(xToCanvas(solutionValue), yToCanvas(0), 6, 0, 2 * Math.PI);
            ctx.fill();
            
            // Add point label
            ctx.fillStyle = '#333';
            ctx.font = 'bold 14px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(`(${solutionValue}, 0)`, xToCanvas(solutionValue), yToCanvas(0) - 15);
            
            // Add equation label
            ctx.fillStyle = '#333';
            ctx.font = 'bold 16px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(originalEquation, width / 2, padding / 2);
            
        } catch (error) {
            console.error('Error drawing equation graph:', error);
            this.drawSolutionPoint(ctx, canvas, variable, solution);
        }
    }
    
    /**
     * Draw just the solution point when we can't determine the full equation
     * @param {CanvasRenderingContext2D} ctx - Canvas context
     * @param {HTMLCanvasElement} canvas - Canvas element
     * @param {string} variable - The variable name
     * @param {number} solution - The solution value
     */
    static drawSolutionPoint(ctx, canvas, variable, solution) {
        // Canvas dimensions
        const width = canvas.width;
        const height = canvas.height;
        
        // Graph settings
        const padding = 40;
        const axisColor = '#999';
        const gridColor = '#eee';
        const pointColor = '#e74c3c';
        
        // Determine graph range
        const solutionValue = parseFloat(solution);
        const xMin = Math.floor(solutionValue - 5);
        const xMax = Math.ceil(solutionValue + 5);
        const yMin = -5;
        const yMax = 5;
        
        // Scale factors
        const xScale = (width - 2 * padding) / (xMax - xMin);
        const yScale = (height - 2 * padding) / (yMax - yMin);
        
        // Functions to convert between coordinate systems
        const xToCanvas = (x) => padding + (x - xMin) * xScale;
        const yToCanvas = (y) => height - padding - (y - yMin) * yScale;
        
        // Draw grid (simplified)
        ctx.strokeStyle = gridColor;
        ctx.lineWidth = 1;
        
        // Vertical grid lines
        for (let x = Math.ceil(xMin); x <= xMax; x++) {
            ctx.beginPath();
            ctx.moveTo(xToCanvas(x), yToCanvas(yMin));
            ctx.lineTo(xToCanvas(x), yToCanvas(yMax));
            ctx.stroke();
            
            // X-axis labels
            ctx.fillStyle = '#666';
            ctx.font = '12px Arial';
            ctx.textAlign = 'center';
            ctx.fillText(x, xToCanvas(x), yToCanvas(yMin) + 20);
        }
        
        // Horizontal grid lines
        for (let y = Math.ceil(yMin); y <= yMax; y++) {
            ctx.beginPath();
            ctx.moveTo(xToCanvas(xMin), yToCanvas(y));
            ctx.lineTo(xToCanvas(xMax), yToCanvas(y));
            ctx.stroke();
            
            // Y-axis labels
            if (y !== 0) {
                ctx.fillStyle = '#666';
                ctx.font = '12px Arial';
                ctx.textAlign = 'right';
                ctx.fillText(y, xToCanvas(xMin) - 10, yToCanvas(y) + 5);
            }
        }
        
        // Draw axes
        ctx.strokeStyle = axisColor;
        ctx.lineWidth = 2;
        
        // X-axis
        ctx.beginPath();
        ctx.moveTo(xToCanvas(xMin), yToCanvas(0));
        ctx.lineTo(xToCanvas(xMax), yToCanvas(0));
        ctx.stroke();
        
        // Y-axis
        ctx.beginPath();
        ctx.moveTo(xToCanvas(0), yToCanvas(yMin));
        ctx.lineTo(xToCanvas(0), yToCanvas(yMax));
        ctx.stroke();
        
        // Draw solution point
        ctx.fillStyle = pointColor;
        ctx.beginPath();
        ctx.arc(xToCanvas(solutionValue), yToCanvas(0), 6, 0, 2 * Math.PI);
        ctx.fill();
        
        // Add point label
        ctx.fillStyle = '#333';
        ctx.font = 'bold 14px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`${variable} = ${solution}`, xToCanvas(solutionValue), yToCanvas(0) - 15);
        
        // Add explanation
        ctx.fillStyle = '#666';
        ctx.font = '14px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`Solution point where ${variable} = ${solution}`, width / 2, height - 15);
    }
}

// Expose the utility to the global scope for use in other scripts
window.GraphUtility = GraphUtility;