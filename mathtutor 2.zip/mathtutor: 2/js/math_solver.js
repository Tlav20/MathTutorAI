// MathTutor - Enhanced Math Solver Component

class MathSolver {
    constructor() {
        this.container = document.getElementById('math-solver-section');
        this.api = new MathAPI();
        this.currentProblem = null;
        this.currentSolution = null;
        this.steps = [];
        this.currentStep = 0;
        this.problemHistory = [];
        
        // Load problem history from localStorage
        this.loadProblemHistory();
        
        this.init();
    }

    init() {
        if (!this.container) return;
        
        // Create HTML structure
        this.render();
        
        // Add event listeners
        this.addEventListeners();
        
        // Render problem history
        this.renderProblemHistory();
    }

    render() {
        this.container.innerHTML = `
            <h2>Math Solver</h2>
            <div class="math-solver">
                <div class="math-input-area">
                    <div class="input-group">
                        <label for="math-problem">Enter your math problem:</label>
                        <textarea id="math-problem" placeholder="E.g., 3x + 4 = 10"></textarea>
                    </div>
                    <div class="input-options">
                        <select id="math-problem-type">
                            <option value="algebra">Algebra</option>
                            <option value="arithmetic">Arithmetic</option>
                            <option value="geometry">Geometry</option>
                            <option value="fractions">Fractions</option>
                            <option value="trigonometry">Trigonometry</option>
                            <option value="calculus">Calculus</option>
                        </select>
                        <button id="solve-btn" class="solve-btn">
                            <i class="fas fa-calculator"></i> Solve
                        </button>
                    </div>
                </div>
                
                <div class="math-result" id="math-result">
                    <div class="result-empty">
                        <!-- Removed image for cleaner UI -->
                        <p>Enter a math problem above and click "Solve" to see the step-by-step solution.</p>
                    </div>
                </div>
                
                <div class="math-solution-steps" id="solution-steps" style="display: none;">
                    <div class="solution-actions">
                        <button id="save-to-notes-btn" class="action-btn">
                            <i class="fas fa-save"></i> Save to Notes
                        </button>
                        <button id="view-graph-btn" class="action-btn" style="display: none;">
                            <i class="fas fa-chart-line"></i> View Graph
                        </button>
                    </div>
                    
                    <h3>Step-by-Step Solution</h3>
                    <div class="steps-container" id="steps-container">
                        <!-- Steps will be added here -->
                    </div>
                    <div class="steps-nav">
                        <button id="prev-step" class="step-btn" disabled>
                            <i class="fas fa-chevron-left"></i> Previous
                        </button>
                        <span id="step-indicator">Step 0 of 0</span>
                        <button id="next-step" class="step-btn" disabled>
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                    </div>
                </div>
                
                <div class="math-history" id="math-history">
                    <div class="history-header">
                        <h3>Recent Problems</h3>
                        <button id="clear-history-btn" class="clear-history-btn">
                            <i class="fas fa-trash-alt"></i> Clear All
                        </button>
                    </div>
                    <div class="history-items" id="history-items">
                        <!-- History items will be added here -->
                        <div class="history-empty">No recent problems yet.</div>
                    </div>
                </div>
            </div>
            
            <!-- Graph Modal -->
            <div id="graph-modal" class="modal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h3>Equation Graph</h3>
                        <span class="close-modal">&times;</span>
                    </div>
                    <div class="modal-body">
                        <div id="graph-container" class="graph-container"></div>
                    </div>
                </div>
            </div>
        `;
    }

    addEventListeners() {
        const solveBtn = document.getElementById('solve-btn');
        const prevStepBtn = document.getElementById('prev-step');
        const nextStepBtn = document.getElementById('next-step');
        const saveToNotesBtn = document.getElementById('save-to-notes-btn');
        const viewGraphBtn = document.getElementById('view-graph-btn');
        const graphModal = document.getElementById('graph-modal');
        const closeModal = document.querySelector('.close-modal');
        const clearHistoryBtn = document.getElementById('clear-history-btn');
        
        if (solveBtn) {
            solveBtn.addEventListener('click', () => this.solveProblem());
        }
        
        if (prevStepBtn) {
            prevStepBtn.addEventListener('click', () => this.showPreviousStep());
        }
        
        if (nextStepBtn) {
            nextStepBtn.addEventListener('click', () => this.showNextStep());
        }
        
        if (saveToNotesBtn) {
            saveToNotesBtn.addEventListener('click', () => this.saveToNotes());
        }
        
        if (viewGraphBtn) {
            viewGraphBtn.addEventListener('click', () => this.showGraph());
        }
        
        if (clearHistoryBtn) {
            clearHistoryBtn.addEventListener('click', () => this.clearAllHistory());
        }
        
        // Close modal when clicking the X
        if (closeModal) {
            closeModal.addEventListener('click', () => {
                if (graphModal) graphModal.style.display = 'none';
            });
        }
        
        // Close modal when clicking outside of it
        window.addEventListener('click', (e) => {
            if (e.target === graphModal) {
                graphModal.style.display = 'none';
            }
        });
        
        // Enable keyboard input for the problem input
        const problemInput = document.getElementById('math-problem');
        if (problemInput) {
            problemInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.solveProblem();
                }
            });
        }
    }

    async solveProblem() {
        const problemInput = document.getElementById('math-problem');
        const problemTypeSelect = document.getElementById('math-problem-type');
        const mathResult = document.getElementById('math-result');
        const solutionSteps = document.getElementById('solution-steps');
        const viewGraphBtn = document.getElementById('view-graph-btn');
        
        if (!problemInput || !problemTypeSelect || !mathResult || !solutionSteps) return;
        
        const problem = problemInput.value.trim();
        const problemType = problemTypeSelect.value;
        
        if (!problem) {
            this.showError('Please enter a math problem');
            return;
        }
        
        try {
            // Show loading state
            mathResult.innerHTML = `
                <div class="loading-container">
                    <div class="loading-spinner"></div>
                    <p>Solving your problem...</p>
                </div>
            `;
            
            // Call API to solve problem
            const solution = await this.api.solveMathProblem(problem, problemType);
            
            // Store current problem and solution
            this.currentProblem = problem;
            this.currentSolution = solution;
            this.steps = solution.steps;
            this.currentStep = 0;
            
            // Show solution
            this.updateSolution();
            solutionSteps.style.display = 'block';
            
            // Show or hide graph button based on problem type
            if (problemType === 'algebra' && solution.variable) {
                viewGraphBtn.style.display = 'inline-flex';
            } else {
                viewGraphBtn.style.display = 'none';
            }
            
            // Add to recent problems
            this.addToRecentProblems(problem, solution.result, problemType);
            
        } catch (error) {
            this.showError('Could not solve the problem. Please try again or rephrase your question.');
            console.error('Math solver error:', error);
        }
    }

    updateSolution() {
        const mathResult = document.getElementById('math-result');
        const stepsContainer = document.getElementById('steps-container');
        const stepIndicator = document.getElementById('step-indicator');
        const prevStepBtn = document.getElementById('prev-step');
        const nextStepBtn = document.getElementById('next-step');
        
        if (!mathResult || !stepsContainer || !stepIndicator || !prevStepBtn || !nextStepBtn) return;
        
        // Update result area
        if (this.steps.length > 0) {
            const finalStep = this.steps[this.steps.length - 1];
            mathResult.innerHTML = `
                <div class="result-content">
                    <div class="result-problem">${this.currentProblem}</div>
                    <div class="result-answer">
                        <div class="answer-label">Answer:</div>
                        <div class="answer-value">${finalStep.result}</div>
                    </div>
                </div>
            `;
            
            // Update steps
            stepsContainer.innerHTML = '';
            
            for (let i = 0; i <= this.currentStep && i < this.steps.length; i++) {
                const step = this.steps[i];
                const stepElement = document.createElement('div');
                stepElement.className = 'solution-step';
                
                // Create step content with enhanced visuals
                stepElement.innerHTML = `
                    <div class="step-number">Step ${i + 1}</div>
                    <div class="step-content">
                        <div class="step-explanation">${step.explanation}</div>
                        <div class="step-formula">${step.equation}</div>
                        ${this.createVisualAid(step, i)}
                    </div>
                `;
                stepsContainer.appendChild(stepElement);
            }
            
            // Update step navigation
            stepIndicator.textContent = `Step ${this.currentStep + 1} of ${this.steps.length}`;
            prevStepBtn.disabled = this.currentStep === 0;
            nextStepBtn.disabled = this.currentStep >= this.steps.length - 1;
            
            // Scroll to the latest step
            const latestStep = stepsContainer.lastElementChild;
            if (latestStep) {
                latestStep.scrollIntoView({ behavior: 'smooth' });
            }
        } else {
            mathResult.innerHTML = `
                <div class="result-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <p>No solution found. Please try a different problem.</p>
                </div>
            `;
            stepsContainer.innerHTML = '';
            stepIndicator.textContent = 'Step 0 of 0';
            prevStepBtn.disabled = true;
            nextStepBtn.disabled = true;
        }
    }

    /**
     * Create visual aid for specific step types
     * @param {Object} step - The step object
     * @param {number} stepIndex - The index of the step
     * @returns {string} - HTML for visual aid
     */
    createVisualAid(step, stepIndex) {
        const solution = this.currentSolution;
        if (!solution) return '';
        
        // Create specific visualizations based on problem type
        if (solution.shape === 'rectangle' && stepIndex === this.steps.length - 1) {
            // Visual for rectangle
            const { length, width, area, perimeter } = solution.properties || {};
            if (length && width) {
                return `
                    <div class="visual-aid">
                        <div class="shape-rectangle" style="width: ${Math.min(300, length * 20)}px; height: ${Math.min(200, width * 20)}px;">
                            <div class="shape-dimension width-dim">${width}</div>
                            <div class="shape-dimension length-dim">${length}</div>
                            ${area ? `<div class="shape-area">Area: ${area}</div>` : ''}
                        </div>
                    </div>
                `;
            }
        } else if (solution.shape === 'square' && stepIndex === this.steps.length - 1) {
            // Visual for square
            const { side, area, perimeter } = solution.properties || {};
            if (side) {
                return `
                    <div class="visual-aid">
                        <div class="shape-square" style="width: ${Math.min(200, side * 20)}px; height: ${Math.min(200, side * 20)}px;">
                            <div class="shape-dimension side-dim">${side}</div>
                            ${area ? `<div class="shape-area">Area: ${area}</div>` : ''}
                        </div>
                    </div>
                `;
            }
        } else if (solution.shape === 'circle' && stepIndex === this.steps.length - 1) {
            // Visual for circle
            const { radius, area, circumference } = solution.properties || {};
            if (radius) {
                return `
                    <div class="visual-aid">
                        <div class="shape-circle" style="width: ${Math.min(200, radius * 40)}px; height: ${Math.min(200, radius * 40)}px;">
                            <div class="shape-radius"></div>
                            <div class="shape-dimension radius-dim">${radius}</div>
                            ${area ? `<div class="shape-area">Area: ${area}</div>` : ''}
                        </div>
                    </div>
                `;
            }
        } else if (solution.shape === 'triangle' && stepIndex === this.steps.length - 1) {
            // Visual for triangle
            const { base, height, area, sides } = solution.properties || {};
            if (base && height) {
                return `
                    <div class="visual-aid">
                        <div class="shape-triangle" style="border-bottom-width: ${Math.min(150, height * 15)}px; border-left-width: ${Math.min(150, base * 15)}px;">
                            <div class="shape-dimension height-dim" style="height: ${Math.min(150, height * 15)}px;">${height}</div>
                            <div class="shape-dimension base-dim" style="width: ${Math.min(150, base * 15)}px;">${base}</div>
                            ${area ? `<div class="shape-area">Area: ${area}</div>` : ''}
                        </div>
                    </div>
                `;
            }
        } else if (solution.variable && stepIndex === this.steps.length - 1) {
            // Preview for algebra problems (full graph will be in modal)
            return `
                <div class="graph-preview">
                    <p>Click "View Graph" to see a visual representation of this equation.</p>
                </div>
            `;
        }
        
        return '';
    }

    showNextStep() {
        if (this.currentStep < this.steps.length - 1) {
            this.currentStep++;
            this.updateSolution();
        }
    }

    showPreviousStep() {
        if (this.currentStep > 0) {
            this.currentStep--;
            this.updateSolution();
        }
    }

    showError(message) {
        const mathResult = document.getElementById('math-result');
        if (!mathResult) return;
        
        mathResult.innerHTML = `
            <div class="result-error">
                <i class="fas fa-exclamation-circle"></i>
                <p>${message}</p>
            </div>
        `;
    }

    /**
     * Add a problem to the recent problems history
     * @param {string} problem - The problem text
     * @param {string} result - The result text
     * @param {string} type - The problem type
     */
    addToRecentProblems(problem, result, type) {
        // Create a history item object
        const historyItem = {
            id: Date.now(),
            problem: problem,
            result: result,
            type: type,
            timestamp: new Date().toISOString()
        };
        
        // Add to the beginning of history array
        this.problemHistory.unshift(historyItem);
        
        // Limit history length to 10 items
        if (this.problemHistory.length > 10) {
            this.problemHistory = this.problemHistory.slice(0, 10);
        }
        
        // Save to localStorage
        this.saveProblemHistory();
        
        // Update the history UI
        this.renderProblemHistory();
    }

    /**
     * Load problem history from localStorage
     */
    loadProblemHistory() {
        const savedHistory = localStorage.getItem('mathTutorProblemHistory');
        if (savedHistory) {
            try {
                this.problemHistory = JSON.parse(savedHistory);
            } catch (error) {
                console.error('Error loading problem history:', error);
                this.problemHistory = [];
            }
        } else {
            this.problemHistory = [];
        }
    }

    /**
     * Save problem history to localStorage
     */
    saveProblemHistory() {
        localStorage.setItem('mathTutorProblemHistory', JSON.stringify(this.problemHistory));
    }

    /**
     * Render the problem history in the UI
     */
    renderProblemHistory() {
        const historyItems = document.getElementById('history-items');
        if (!historyItems) return;
        
        if (this.problemHistory.length === 0) {
            historyItems.innerHTML = `<div class="history-empty">No recent problems yet.</div>`;
            return;
        }
        
        historyItems.innerHTML = '';
        
        this.problemHistory.forEach(item => {
            const historyItem = document.createElement('div');
            historyItem.className = 'history-item';
            historyItem.dataset.id = item.id;
            
            const date = new Date(item.timestamp);
            const formattedDate = date.toLocaleDateString('en-US', { 
                month: 'short', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
            });
            
            historyItem.innerHTML = `
                <div class="history-problem">${item.problem}</div>
                <div class="history-details">
                    <span class="history-result">${item.result}</span>
                    <span class="history-type">${item.type}</span>
                    <span class="history-time">${formattedDate}</span>
                </div>
                <div class="history-actions">
                    <button class="history-solve-again" title="Solve again">
                        <i class="fas fa-redo"></i>
                    </button>
                    <button class="history-delete" title="Delete from history">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            `;
            
            // Add click event to "Solve Again" button
            const solveAgainBtn = historyItem.querySelector('.history-solve-again');
            solveAgainBtn.addEventListener('click', () => this.solveHistoryProblem(item.id));
            
            // Add click event to "Delete" button
            const deleteBtn = historyItem.querySelector('.history-delete');
            deleteBtn.addEventListener('click', (e) => {
                e.stopPropagation(); // Prevent triggering parent element clicks
                this.deleteHistoryItem(item.id);
            });
            
            historyItems.appendChild(historyItem);
        });
    }

    /**
     * Solve a problem from history
     * @param {number} id - The history item ID
     */
    solveHistoryProblem(id) {
        const historyItem = this.problemHistory.find(item => item.id === id);
        if (!historyItem) return;
        
        // Set problem input and type
        const problemInput = document.getElementById('math-problem');
        const problemTypeSelect = document.getElementById('math-problem-type');
        
        if (problemInput && problemTypeSelect) {
            problemInput.value = historyItem.problem;
            problemTypeSelect.value = historyItem.type;
            
            // Solve the problem
            this.solveProblem();
            
            // Scroll to top of solver
            this.container.scrollIntoView({ behavior: 'smooth' });
        }
    }

    /**
     * Delete an item from the problem history
     * @param {number} id - The history item ID
     */
    deleteHistoryItem(id) {
        // Show confirmation dialog
        if (confirm('Are you sure you want to delete this problem from history?')) {
            // Find index of the item
            const itemIndex = this.problemHistory.findIndex(item => item.id === id);
            
            if (itemIndex !== -1) {
                // Remove the item
                this.problemHistory.splice(itemIndex, 1);
                
                // Save updated history to localStorage
                this.saveProblemHistory();
                
                // Re-render the history
                this.renderProblemHistory();
                
                // Show notification
                this.showNotification('Problem deleted from history', 'success');
            }
        }
    }

    /**
     * Clear all history items
     */
    clearAllHistory() {
        // Show confirmation dialog
        if (confirm('Are you sure you want to clear all history?')) {
            // Clear the history array
            this.problemHistory = [];
            
            // Save to localStorage
            this.saveProblemHistory();
            
            // Re-render the history
            this.renderProblemHistory();
            
            // Show notification
            this.showNotification('History cleared', 'success');
        }
    }

    /**
     * Save current problem and solution to notes
     */
    saveToNotes() {
        if (!this.currentProblem || !this.currentSolution) {
            this.showNotification('No problem to save', 'error');
            return;
        }
        
        try {
            // Format the content for the note
            let noteContent = `# Problem: ${this.currentProblem}\n\n`;
            noteContent += `**Answer: ${this.currentSolution.result}**\n\n`;
            noteContent += `## Step-by-Step Solution\n\n`;
            
            // Add steps
            this.steps.forEach((step, index) => {
                noteContent += `### Step ${index + 1}\n`;
                noteContent += `${step.explanation}\n\n`;
                noteContent += `\`${step.equation}\`\n\n`;
            });
            
            // Add timestamp
            const date = new Date();
            noteContent += `\n---\n`;
            noteContent += `Saved on ${date.toLocaleDateString()} at ${date.toLocaleTimeString()}`;
            
            // Get existing notes from localStorage
            let notes = [];
            const savedNotes = localStorage.getItem('mathTutorNotes');
            
            if (savedNotes) {
                notes = JSON.parse(savedNotes);
            }
            
            // Create new note
            const newNote = {
                id: 'note_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                title: `Math Problem: ${this.currentProblem}`,
                content: noteContent,
                created: Date.now(),
                lastModified: Date.now()
            };
            
            // Add to notes array
            notes.unshift(newNote);
            
            // Save back to localStorage
            localStorage.setItem('mathTutorNotes', JSON.stringify(notes));
            
            // Show success notification
            this.showNotification('Problem saved to notes!', 'success');
            
        } catch (error) {
            console.error('Error saving to notes:', error);
            this.showNotification('Error saving to notes', 'error');
        }
    }

    /**
     * Show an equation graph for algebra problems
     */
    showGraph() {
        if (!this.currentSolution || !this.currentSolution.variable) {
            this.showNotification('No equation to graph', 'error');
            return;
        }
        
        const graphModal = document.getElementById('graph-modal');
        const graphContainer = document.getElementById('graph-container');
        
        if (!graphModal || !graphContainer) return;
        
        // Clear previous graph
        graphContainer.innerHTML = '';
        
        // Show modal
        graphModal.style.display = 'block';
        
        try {
            // Create canvas for graph
            const canvas = document.createElement('canvas');
            canvas.id = 'equation-graph';
            canvas.width = graphContainer.clientWidth;
            canvas.height = 400;
            graphContainer.appendChild(canvas);
            
            // Create graph description
            const description = document.createElement('div');
            description.className = 'graph-description';
            
            // Extract information from the solution
            const { variable, solution } = this.currentSolution;
            
            // Use GraphUtility to create the graph
            if (window.GraphUtility) {
                window.GraphUtility.createEquationGraph('equation-graph', this.currentSolution, this.currentProblem);
                
                description.innerHTML = `
                    <p>Graph showing the equation ${this.currentProblem}</p>
                    <p>The solution is ${variable} = ${solution}, represented by the red point where the line crosses the x-axis.</p>
                `;
            } else {
                // Fallback if GraphUtility is not available
                const ctx = canvas.getContext('2d');
                ctx.font = '16px Arial';
                ctx.fillText('Graph utility not loaded. Please include graph_utility.js', 50, 150);
                ctx.fillText(`Equation: ${this.currentProblem}`, 50, 180);
                ctx.fillText(`Solution: ${variable} = ${solution}`, 50, 210);
                
                description.innerHTML = `
                    <p>Unable to display graph. Please make sure the graph utility is loaded.</p>
                `;
            }
            
            graphContainer.appendChild(description);
            
        } catch (error) {
            console.error('Error creating graph:', error);
            graphContainer.innerHTML = '<p class="error">Error creating graph</p>';
        }
    }

    /**
     * Show a notification
     * @param {string} message - The notification message
     * @param {string} type - 'success' or 'error'
     */
    showNotification(message, type = 'success') {
        // Create notification element if it doesn't exist
        let notification = document.getElementById('math-notification');
        
        if (!notification) {
            notification = document.createElement('div');
            notification.id = 'math-notification';
            notification.className = 'notification';
            document.body.appendChild(notification);
        }
        
        // Set type class
        notification.className = `notification ${type}`;
        
        // Set message and icon
        const icon = type === 'success' ? 'check-circle' : 'exclamation-circle';
        notification.innerHTML = `<i class="fas fa-${icon}"></i> ${message}`;
        
        // Show with animation
        notification.classList.add('show');
        
        // Hide after delay
        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }
}

// Initialize the Enhanced Math Solver when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    const mathSolver = new MathSolver();
});